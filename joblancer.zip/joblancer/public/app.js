(function () {
'use strict';
var $ = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
var inr = function (p) { return '₹' + (Number(p) / 100).toLocaleString('en-IN', { maximumFractionDigits: 2 }); };
var when = function (ms) { return ms ? new Date(ms).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : ''; };
var day = function (ms) { return ms ? new Date(ms).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : ''; };
var pl = function (n, w) { return n + ' ' + w + (n === 1 ? '' : 's'); };
function ago(ms) { var m = Math.round((Date.now() - ms) / 60000); if (m < 2) return 'Just now'; if (m < 60) return m + ' min ago'; if (m < 1440) return Math.round(m / 60) + ' h ago'; return Math.round(m / 1440) + ' d ago'; }

var S = { user: null, meta: null, F: { q: '', cat: 'All', skill: '', sort: 'new', page: 0 }, jobs: [], total: 0, post: { cat: '', skills: [] }, exam: null, atab: 'overview', afterAuth: null };
var SHIELD = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1l6 2v4.5c0 3.2-2.3 5.7-6 7.5C4.3 13.2 2 10.7 2 7.5V3z" fill="currentColor"/><path d="M5.5 8l1.8 1.8L10.8 6.2" fill="none" stroke="var(--surface)" stroke-width="1.6"/></svg>';

/* ---------- helpers ---------- */
var tt;
function toast(m, bad) { var t = $('#toast'); t.textContent = m; t.className = 'toast show' + (bad ? ' bad' : ''); clearTimeout(tt); tt = setTimeout(function () { t.className = 'toast'; }, 4200); }
async function api(method, url, body) {
  var opt = { method: method, credentials: 'same-origin', headers: {} };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  var r = await fetch(url, opt), d = null;
  try { d = await r.json(); } catch (e) { /* empty */ }
  if (!r.ok) {
    var e = new Error((d && d.error) || 'Something went wrong. Please try again.');
    e.status = r.status; e.data = d;
    if (r.status === 401 && S.user) { S.user = null; paintHeader(); paintBanner(); }
    throw e;
  }
  return d;
}
function errBox(el, e) { if (!el) { toast(typeof e === 'string' ? e : e.message, true); return; } el.hidden = false; el.className = 'alert'; el.textContent = typeof e === 'string' ? e : e.message; }
function clearErr(el) { if (el) { el.hidden = true; el.textContent = ''; } }
function busy(btn, on, label) { if (!btn) return; if (on) { btn.dataset.l = btn.textContent; btn.disabled = true; if (label) btn.textContent = label; } else { btn.disabled = false; if (btn.dataset.l) btn.textContent = btn.dataset.l; } }
function planOf(key) { return S.meta.plans.filter(function (p) { return p.key === key; })[0]; }
function catByName(n) { return S.meta.cats.filter(function (c) { return c.n === n; })[0]; }
function catOptions(sel, withBlank) { return (withBlank ? '<option value="">' + esc(withBlank) + '</option>' : '') + S.meta.cats.map(function (c) { return '<option' + (c.n === sel ? ' selected' : '') + '>' + esc(c.n) + '</option>'; }).join(''); }
function chipsHtml(opts, sel) { return opts.map(function (o) { return '<button type="button" class="chip" data-v="' + esc(o) + '" aria-pressed="' + (sel.indexOf(o) >= 0) + '">' + esc(o) + '</button>'; }).join(''); }
function bindChips(box, opts, sel, max, cb) {
  if (!opts.length) { box.innerHTML = '<span class="hint">Choose a category first.</span>'; box.onclick = null; return; }
  box.innerHTML = chipsHtml(opts, sel);
  box.onclick = function (e) {
    var b = e.target.closest('.chip'); if (!b) return;
    var v = b.dataset.v, i = sel.indexOf(v);
    if (i >= 0) sel.splice(i, 1); else { if (sel.length >= max) { toast('You can choose up to ' + max + '.', true); return; } sel.push(v); }
    b.setAttribute('aria-pressed', String(sel.indexOf(v) >= 0));
    if (cb) cb();
  };
}
function scan(t, allowLinks) {
  var r = [], s = String(t);
  if (/(?:\+?91[\s.-]*)?[6-9](?:[\s.-]*\d){9}/.test(s)) r.push('Phone numbers are not allowed.');
  if (/[\w.+-]+\s?(@|\[at\]|\(at\))\s?[\w-]+\s?(\.|\[dot\]|\(dot\))\s?[a-z]{2,}/i.test(s)) r.push('Email addresses are not allowed.');
  if (/(t\.me\/|wa\.me\/|chat\.whatsapp|discord\.gg|telegram\.me)/i.test(s) || /\b(whats\s?app|telegram|signal app|skype)\b/i.test(s)) r.push('Chat app contacts are not allowed.');
  if (/(pay|paid|send|transfer|payment).{0,25}(outside|directly|direct|offline|upi|gpay|google pay|phonepe|paytm|bank account)/i.test(s) || /(outside (the )?platform|off[- ]platform)/i.test(s)) r.push('Payments outside JobLancer are not allowed.');
  if (/(registration fee|security deposit|joining fee|advance fee|refundable|pay first|processing fee|training fee)/i.test(s)) r.push('Asking for fees or deposits is not allowed.');
  if (/(crypto|bitcoin|investment plan|double your|lottery|guaranteed (income|returns|profit)|trading signal)/i.test(s)) r.push('This looks like an investment offer, not a freelance job.');
  if (!allowLinks && /(https?:\/\/|www\.)\S+/i.test(s)) r.push('Links are not allowed here. They open up after escrow is funded.');
  return r;
}
var arm = function (btn, label) { if (btn.dataset.armed) return true; btn.dataset.armed = '1'; btn.dataset.orig = btn.textContent; btn.textContent = label; setTimeout(function () { if (btn.isConnected) { delete btn.dataset.armed; btn.textContent = btn.dataset.orig; } }, 4000); return false; };

var CSTATUS = { awaiting_payment: ['Waiting for payment', 'warn'], funded: ['In progress', 'go'], delivered: ['Delivered, under review', 'go'], released: ['Completed', ''], disputed: ['In dispute', 'stop'], refunded: ['Refunded', ''] };
var BSTATUS = { pending: ['Pending', 'warn'], accepted: ['Hired', 'go'], rejected: ['Not selected', ''], withdrawn: ['Withdrawn', ''] };
var pill = function (map, k) { var m = map[k] || [k, '']; return '<span class="pill ' + m[1] + '">' + esc(m[0]) + '</span>'; };

/* ---------- theme ---------- */
(function () { try { var t = localStorage.getItem('jl-theme'); if (t) document.documentElement.setAttribute('data-theme', t); } catch (e) { /* ignore */ } })();
function toggleTheme() {
  var cur = document.documentElement.getAttribute('data-theme');
  var dark = cur ? cur === 'dark' : (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  var n = dark ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', n);
  try { localStorage.setItem('jl-theme', n); } catch (e) { /* ignore */ }
}

/* ---------- panels ---------- */
function openPanel(html) { $('#panel').innerHTML = html; $('#ov').hidden = false; $('#panel').scrollTop = 0; }
function closePanel() { $('#ov').hidden = true; $('#panel').innerHTML = ''; stopThread(); }
function panelHead(title, eyebrow) { return '<div class="panel-h"><div>' + (eyebrow ? '<p class="eyebrow">' + esc(eyebrow) + '</p>' : '') + '<h2>' + esc(title) + '</h2></div><button class="icon-btn" type="button" data-act="close-panel" aria-label="Close">✕</button></div>'; }
function panelError(e) { openPanel(panelHead('Something went wrong') + '<div class="alert">' + esc(e.message) + '</div>'); }

/* ---------- header / banner ---------- */
function navItems() {
  var u = S.user;
  if (!u) return [['home', 'Find work'], ['post', 'Post a job'], ['pricing', 'Pricing'], ['trust', 'Trust & safety']];
  if (u.role === 'client') return [['home', 'Browse jobs'], ['post', 'Post a job'], ['dashboard', 'Dashboard'], ['trust', 'Trust & safety']];
  if (u.role === 'freelancer') return [['home', 'Find work'], ['dashboard', 'Dashboard'], ['pricing', 'Plans'], ['trust', 'Trust & safety']];
  return [['admin', 'Admin'], ['home', 'Jobs']];
}
function paintHeader() {
  var cur = S.route;
  $('#nav').innerHTML = navItems().map(function (n) { return '<button type="button" data-go="' + n[0] + '"' + (n[0] === cur ? ' aria-current="page"' : '') + '>' + n[1] + '</button>'; }).join('');
  var u = S.user, h = '';
  if (!u) h = '<button class="btn ghost sm" type="button" data-act="auth" data-mode="login">Log in</button><button class="btn sm" type="button" data-act="auth" data-mode="register">Sign up</button>';
  else h = '<button class="userbtn" type="button" data-go="account" title="Your account"><span class="av">' + esc(u.name[0].toUpperCase()) + '</span><span class="t">' + esc(u.name.split(' ')[0]) + (u.role === 'freelancer' ? ' · ' + u.bidsLeft + ' bids' : '') + '</span></button><button class="btn ghost sm" type="button" data-act="logout">Log out</button>';
  h += '<button class="icon-btn" type="button" data-act="theme" aria-label="Switch theme"><svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 2a6 6 0 0 0 0 12z" fill="currentColor"/></svg></button>';
  $('#hdrR').innerHTML = h;
}
function paintBanner() {
  var u = S.user, b = $('#banner');
  if (!u || u.role === 'admin') { b.innerHTML = ''; return; }
  var todo = [];
  if (!u.phoneVerified) todo.push('verify your mobile number');
  if (!u.emailVerified) todo.push('verify your email');
  if (u.role === 'client') { if (u.panStatus === 'none' || u.panStatus === 'rejected') todo.push('verify your PAN'); else if (u.panStatus === 'pending') todo.push('wait for PAN approval'); }
  if (u.role === 'freelancer' && !u.badges.length) todo.push('pass a skill exam');
  if (!todo.length || S.route === 'account') { b.innerHTML = ''; return; }
  b.innerHTML = '<div class="bn"><div class="wrap"><span><b>Finish setup to ' + (u.role === 'client' ? 'post jobs' : 'start bidding') + ':</b> ' + todo.join(', ') + '.</span><button class="btn sm" type="button" data-go="account">Continue</button></div></div>';
}
async function refreshMe() { var d = await api('GET', '/api/me'); S.user = d.user; paintHeader(); paintBanner(); return S.user; }

/* ---------- router ---------- */
var R = {};
function route() {
  var h = location.hash.replace('#', '') || 'home', anchor = false;
  if (h === 'jobs') { h = 'home'; anchor = true; }
  if (!R[h]) h = 'home';
  S.route = h; stopExamTimer(); closePanel(); paintHeader(); paintBanner();
  R[h]();
  if (anchor && $('#jobs')) $('#jobs').scrollIntoView(); else window.scrollTo(0, 0);
}
function go(h) { if (location.hash === '#' + h) route(); else location.hash = h; }
window.addEventListener('hashchange', route);
function gate(title, text, role) {
  $('#app').innerHTML = '<div class="wrap sec"><div class="card stack" style="max-width:560px"><h2>' + esc(title) + '</h2><p class="muted">' + esc(text) + '</p><div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn" type="button" data-act="auth" data-mode="register" data-role="' + (role || '') + '">Create account</button><button class="btn ghost" type="button" data-act="auth" data-mode="login">Log in</button></div></div></div>';
}

/* ======================= AUTH ======================= */
var A = { mode: 'login', role: '', step: 1, email: '' };
function openAuth(mode, role) { A = { mode: mode || 'login', role: role || '', step: 1, email: '' }; drawAuth(); $('#authOv').hidden = false; var f = $('#authBox input'); if (f) f.focus(); }
function closeAuth() { $('#authOv').hidden = true; $('#authBox').innerHTML = ''; }
function drawAuth() {
  var b = $('#authBox'), h = '';
  var head = '<div style="display:flex;justify-content:space-between;align-items:center"><div class="logo" style="cursor:default"><span class="logo-mk">J</span>JobLancer</div><button class="icon-btn" type="button" data-act="close-auth" aria-label="Close">✕</button></div>';
  if (A.mode === 'forgot') {
    h = head + '<h2>Reset your password</h2>' + (A.step === 1
      ? '<form class="stack" data-form="forgot1" novalidate><div class="field"><label class="lb" for="fgE">Your account email</label><input class="inp" id="fgE" type="email" autocomplete="email" required></div><div id="authErr" hidden></div><button class="btn" type="submit">Send reset code</button></form>'
      : '<form class="stack" data-form="forgot2" novalidate><p class="muted">We sent a 6-digit code to <b>' + esc(A.email) + '</b>.' + (A.dev ? ' <span class="pill warn">Test mode code: ' + esc(A.dev) + '</span>' : '') + '</p><div class="field"><label class="lb" for="fgC">Code</label><input class="inp mono" id="fgC" inputmode="numeric" maxlength="6" autocomplete="one-time-code"></div><div class="field"><label class="lb" for="fgP">New password</label><input class="inp" id="fgP" type="password" autocomplete="new-password"><p class="hint">At least 8 characters with a letter and a number.</p></div><div id="authErr" hidden></div><button class="btn" type="submit">Set new password</button></form>')
      + '<button class="lnk" type="button" data-act="auth" data-mode="login">Back to log in</button>';
  } else {
    h = head + '<div class="tabs" role="tablist"><button type="button" data-act="auth" data-mode="login" aria-pressed="' + (A.mode === 'login') + '">Log in</button><button type="button" data-act="auth" data-mode="register" aria-pressed="' + (A.mode === 'register') + '">Sign up</button></div>';
    if (A.mode === 'login') {
      h += '<form class="stack" data-form="login" novalidate><div class="field"><label class="lb" for="lgE">Email</label><input class="inp" id="lgE" type="email" autocomplete="email" required></div><div class="field"><label class="lb" for="lgP">Password</label><input class="inp" id="lgP" type="password" autocomplete="current-password" required></div><div id="authErr" hidden></div><button class="btn" type="submit">Log in</button><button class="lnk" type="button" data-act="auth" data-mode="forgot" style="align-self:flex-start">Forgot password?</button></form>';
    } else {
      h += '<form class="stack" data-form="register" novalidate><div><p class="lb">What do you want to do?</p><div class="roles">' +
        '<button type="button" class="rolecard" data-act="role" data-role="freelancer" aria-pressed="' + (A.role === 'freelancer') + '"><b>I want to take work</b><span>Freelancer. Bid on jobs and get paid safely.</span></button>' +
        '<button type="button" class="rolecard" data-act="role" data-role="client" aria-pressed="' + (A.role === 'client') + '"><b>I want to give work</b><span>Client. Post jobs and hire verified talent.</span></button></div></div>' +
        '<div class="field"><label class="lb" for="rgN">Full name</label><input class="inp" id="rgN" autocomplete="name" maxlength="60"></div>' +
        '<div class="row2"><div class="field"><label class="lb" for="rgE">Email</label><input class="inp" id="rgE" type="email" autocomplete="email"></div><div class="field"><label class="lb" for="rgM">Mobile number</label><input class="inp" id="rgM" inputmode="numeric" maxlength="10" autocomplete="tel-national" placeholder="10 digits"></div></div>' +
        (A.role === 'freelancer' ? '<div class="field"><label class="lb" for="rgC">Your main field</label><select class="inp" id="rgC">' + catOptions('', 'Select your field') + '</select></div>' : '') +
        '<div class="field"><label class="lb" for="rgP">Password</label><input class="inp" id="rgP" type="password" autocomplete="new-password"><p class="hint">At least 8 characters with a letter and a number.</p></div>' +
        '<div id="authErr" hidden></div><button class="btn" type="submit"' + (A.role ? '' : ' disabled') + '>' + (A.role ? 'Create account' : 'Choose an option above') + '</button></form>';
    }
  }
  b.innerHTML = h;
}
async function afterLogin(user, isNew) {
  S.user = user; closeAuth(); paintHeader();
  var cb = S.afterAuth; S.afterAuth = null;
  if (isNew) { go('account'); toast('Account created. Verify your mobile and email to continue.'); return; }
  if (user.role === 'admin') { go('admin'); return; }
  if (cb) { route(); cb(); return; }
  route(); toast('Welcome back, ' + user.name.split(' ')[0] + '.');
}
async function submitForm(form, e) {
  var kind = form.dataset.form, btn = $('button[type=submit]', form), err = $('#authErr', form) || $('.ferr', form);
  clearErr(err);
  try {
    busy(btn, true);
    if (kind === 'login') { var d = await api('POST', '/api/auth/login', { email: $('#lgE').value, password: $('#lgP').value }); await afterLogin(d.user, false); }
    else if (kind === 'register') {
      var body = { role: A.role, name: $('#rgN').value, email: $('#rgE').value, phone: $('#rgM').value, password: $('#rgP').value };
      if (A.role === 'freelancer') body.category = $('#rgC').value;
      var r = await api('POST', '/api/auth/register', body); await afterLogin(r.user, true);
    }
    else if (kind === 'forgot1') { A.email = $('#fgE').value.trim(); var f = await api('POST', '/api/auth/forgot', { email: A.email }); A.step = 2; A.dev = f.devCode || ''; drawAuth(); }
    else if (kind === 'forgot2') { await api('POST', '/api/auth/reset', { email: A.email, code: $('#fgC').value, password: $('#fgP').value }); toast('Password changed. Log in with your new password.'); openAuth('login'); }
    else await otherForms(kind, form, btn, err);
  } catch (ex) { errBox(err, ex); }
  finally { if (btn && btn.isConnected) busy(btn, false); }
}

/* ======================= HOME / JOBS ======================= */
R.home = function () {
  var u = S.user;
  var cta = !u ? '<button class="btn" type="button" data-act="auth" data-mode="register" data-role="client">Hire talent</button><button class="btn ghost" type="button" data-act="auth" data-mode="register" data-role="freelancer">Find work</button>'
    : u.role === 'client' ? '<button class="btn" type="button" data-go="post">Post a job</button><button class="btn ghost" type="button" data-go="dashboard">My dashboard</button>'
    : u.role === 'freelancer' ? '<button class="btn" type="button" data-go="jobs">Browse jobs</button><button class="btn ghost" type="button" data-go="dashboard">My dashboard</button>' : '<button class="btn" type="button" data-go="admin">Open admin</button>';
  $('#app').innerHTML = '<div class="wrap"><div class="hero"><div><p class="eyebrow">Freelance marketplace for India</p><h1 style="margin-top:12px">Hire verified freelancers. <em>Pay only when the work is approved.</em></h1>' +
    '<p class="lead">Every payment sits in escrow. Every client and every freelancer is checked before the first message is sent.</p>' +
    '<form class="hero-search" id="heroSearch"><input class="inp" id="heroQ" type="search" placeholder="Search a skill, e.g. GST filing, Shopify, voice over" aria-label="Search jobs"><button class="btn" type="submit">Search</button></form><div class="hero-cta">' + cta + '</div></div>' +
    '<div class="card ledger" aria-label="How escrow works"><div class="ledger-h"><span>How escrow works</span><span class="badge teal">Example</span></div><div class="ledger-b"><span class="muted" style="font-size:13px">Held in escrow</span><div class="ledger-amt">₹18,000</div>' +
    '<ol class="steps"><li class="done"><span class="dot">✓</span><span>Client funds the milestone<small>Money is held, not sent</small></span></li><li class="now"><span class="dot"></span><span>Freelancer delivers<small>Work stays on JobLancer</small></span></li><li><span class="dot"></span><span>Client approves</span></li><li><span class="dot"></span><span>Payment released, minus commission</span></li></ol></div></div></div></div>' +
    '<div class="wrap sec" id="jobs" style="padding-top:8px"><div class="sec-h"><div><p class="eyebrow">Open jobs</p><h2>Find work in any skill</h2></div><span class="muted" id="jobCount"></span></div>' +
    '<div class="toolbar"><input class="inp" id="q" type="search" placeholder="Search by title, skill or category" aria-label="Search jobs" value="' + esc(S.F.q) + '"><select class="inp" id="sort" aria-label="Sort jobs"><option value="new">Newest first</option><option value="high">Budget: high to low</option><option value="low">Budget: low to high</option><option value="few">Fewest bids</option></select></div>' +
    '<div class="catrow" id="catRow" role="group" aria-label="Categories"></div><div class="chips skillrow" id="skillRow" role="group" aria-label="Skills" hidden></div><div class="jobs" id="jobList"><div class="skeleton" style="grid-column:1/-1">Loading jobs…</div></div><div id="moreBox" style="margin-top:16px;text-align:center"></div></div>';
  $('#sort').value = S.F.sort;
  paintCats(); loadJobs(false);
};
function paintCats() {
  var F = S.F;
  $('#catRow').innerHTML = '<button type="button" class="chip" data-c="All" aria-pressed="' + (F.cat === 'All') + '">All skills</button>' + S.meta.cats.map(function (c) { return '<button type="button" class="chip" data-c="' + esc(c.n) + '" aria-pressed="' + (F.cat === c.n) + '">' + esc(c.n) + '</button>'; }).join('');
  var sr = $('#skillRow');
  if (F.cat === 'All') { sr.hidden = true; sr.innerHTML = ''; }
  else { sr.hidden = false; sr.innerHTML = catByName(F.cat).s.map(function (s) { return '<button type="button" class="chip" data-s="' + esc(s) + '" aria-pressed="' + (F.skill === s) + '">' + esc(s) + '</button>'; }).join(''); }
}
async function loadJobs(more) {
  var F = S.F; if (!more) F.page = 0;
  var qs = new URLSearchParams({ sort: F.sort, page: F.page });
  if (F.q) qs.set('q', F.q); if (F.cat !== 'All') qs.set('cat', F.cat); if (F.skill) qs.set('skill', F.skill);
  try { var d = await api('GET', '/api/jobs?' + qs); S.total = d.total; S.jobs = more ? S.jobs.concat(d.jobs) : d.jobs; paintJobs(); }
  catch (e) { if ($('#jobList')) $('#jobList').innerHTML = '<div class="empty" style="grid-column:1/-1">' + esc(e.message) + '</div>'; }
}
function paintJobs() {
  if (!$('#jobList')) return;
  $('#jobCount').textContent = S.total + (S.total === 1 ? ' job' : ' jobs');
  if (!S.jobs.length) {
    var filtered = S.F.q || S.F.cat !== 'All' || S.F.skill;
    $('#jobList').innerHTML = '<div class="empty" style="grid-column:1/-1">' + (filtered ? 'No jobs match this search. Try another skill or clear the filters.' : 'No jobs are open right now. Be the first to <button class="lnk" type="button" data-go="post">post a job</button>.') + '</div>';
    $('#moreBox').innerHTML = ''; return;
  }
  $('#jobList').innerHTML = S.jobs.map(function (j) {
    return '<article class="job" data-act="job" data-id="' + j.id + '" tabindex="0"><div class="job-top"><h3>' + esc(j.title) + '</h3><div class="amt">' + inr(j.budgetPaise) + '</div></div><p class="job-desc">' + esc(j.description) + '</p>' +
      '<div class="tags">' + j.skills.map(function (s) { return '<span class="tag">' + esc(s) + '</span>'; }).join('') + '</div><div class="badges"><span class="badge">' + SHIELD + 'Client verified</span><span class="badge teal">Payment protected</span></div>' +
      '<div class="job-foot"><span>' + ago(j.createdAt) + ' · ' + j.days + ' days · ' + j.bids + (j.bids === 1 ? ' bid' : ' bids') + '</span><button class="btn sm" type="button" data-act="job" data-id="' + j.id + '">View details</button></div></article>';
  }).join('');
  $('#moreBox').innerHTML = S.jobs.length < S.total ? '<button class="btn ghost" type="button" data-act="more">Load more jobs</button>' : '';
}

/* ---------- job panel ---------- */
async function openJob(id) {
  openPanel('<div class="skeleton">Loading…</div>');
  try {
    var j = (await api('GET', '/api/jobs/' + id)).job, bids = null;
    if (j.mine) bids = (await api('GET', '/api/jobs/' + id + '/bids')).bids;
    renderJob(j, bids);
  } catch (e) { panelError(e); }
}
function renderJob(j, bids) {
  var u = S.user, h = panelHead(j.title, j.category) +
    '<div class="kv"><div><b>' + inr(j.budgetPaise) + '</b><span>Fixed budget</span></div><div><b>' + j.days + ' days</b><span>Deadline</span></div><div><b>' + (j.bids || 0) + '</b><span>Bids so far</span></div></div>' +
    '<p class="desc">' + esc(j.description) + '</p><div class="tags">' + j.skills.map(function (s) { return '<span class="tag">' + esc(s) + '</span>'; }).join('') + '</div>' +
    '<div class="card stack" style="gap:10px"><b>' + esc(j.client ? j.client.name : 'You') + '</b><ul class="vlist"><li><span class="badge">' + SHIELD + 'Verified</span>Mobile, email and PAN checked</li><li><span class="badge teal">Protected</span>Payment is held in escrow before work starts</li></ul></div>';
  if (j.mine) {
    h += '<h3 class="sub">Bids (' + bids.length + ')</h3>' + (bids.length ? bids.map(function (b) {
      var f = b.freelancer;
      return '<div class="bidcard"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><b>' + esc(f.name) + '</b> ' + f.badges.map(function (x) { return '<span class="badge">' + SHIELD + esc(x.category) + '</span>'; }).join(' ') + '<div class="fine">' + f.completed + ' completed · ' + esc(f.skills.slice(0, 4).join(', ')) + '</div></div><div style="text-align:right"><div class="amt">' + inr(b.amountPaise) + '</div><div class="fine">' + b.days + ' days</div></div></div><p>' + esc(b.note) + '</p>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">' + pill(BSTATUS, b.status) + '<button class="btn ghost sm" type="button" data-act="thread" data-id="' + b.id + '" data-title="' + esc(j.title) + '">Message</button>' +
        (b.status === 'pending' && j.status === 'open' ? '<button class="btn sm" type="button" data-act="accept" data-id="' + b.id + '" data-name="' + esc(f.name) + '">Hire ' + esc(f.name.split(' ')[0]) + '</button>' : '') + '</div></div>';
    }).join('') : '<div class="empty" style="padding:20px 0">No bids yet. Freelancers who pass the skill exam will bid soon.</div>') +
      (j.status === 'open' ? '<div><button class="btn ghost sm" type="button" data-act="close-job" data-id="' + j.id + '">Close this job</button></div>' : '<p class="fine">Status: ' + esc(j.status.replace('_', ' ')) + '</p>');
  } else if (!u) {
    h += '<div class="note stack" style="gap:10px"><b>Log in to bid</b><span>Create a free freelancer account, verify your mobile and pass a short skill exam.</span><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn sm" type="button" data-act="auth-job" data-mode="register" data-role="freelancer" data-id="' + j.id + '">Sign up as freelancer</button><button class="btn ghost sm" type="button" data-act="auth-job" data-mode="login" data-id="' + j.id + '">Log in</button></div></div>';
  } else if (u.role !== 'freelancer') {
    h += '<div class="note">' + (u.role === 'client' ? 'You are logged in as a client. Only freelancers can bid.' : 'Admins cannot bid.') + '</div>';
  } else if (j.myBid) {
    h += '<div class="okbox stack" style="gap:8px"><b>You bid ' + inr(j.myBid.amountPaise) + ' in ' + j.myBid.days + ' days</b><span>Status: ' + pill(BSTATUS, j.myBid.status) + '</span><div><button class="btn sm" type="button" data-act="thread" data-id="' + j.myBid.id + '" data-title="' + esc(j.title) + '">Open messages</button></div></div>';
  } else if (!u.phoneVerified || !u.emailVerified) {
    h += '<div class="note stack" style="gap:10px"><b>Verify your contact details to bid</b><div><button class="btn sm" type="button" data-go="account">Verify now</button></div></div>';
  } else if (!j.hasBadge) {
    h += '<div class="note stack" style="gap:10px"><b>Pass the ' + esc(j.category) + ' exam to bid on this job</b><span>It is 8 questions and takes about 10 minutes. This keeps fake profiles out.</span><div><button class="btn sm" type="button" data-act="exam-for" data-cat="' + esc(j.category) + '">Take the ' + esc(j.category) + ' exam</button></div></div>';
  } else if (j.status !== 'open') {
    h += '<div class="note">This job is no longer open for bids.</div>';
  } else if (u.bidsLeft <= 0) {
    h += '<div class="note stack" style="gap:10px"><b>You have used all bids for this month</b><div><button class="btn sm" type="button" data-go="pricing">See plans</button></div></div>';
  } else {
    var fee = planOf(u.plan).feePct;
    h += '<form class="stack" data-form="bid" data-id="' + j.id + '" data-fee="' + fee + '" novalidate><h3 class="sub">Send your proposal</h3><div class="row2"><div class="field"><label class="lb" for="bAmt">Your price (₹)</label><input class="inp mono" id="bAmt" inputmode="numeric" value="' + Math.round(j.budgetPaise / 100) + '"></div><div class="field"><label class="lb" for="bDays">Delivery (days)</label><input class="inp mono" id="bDays" inputmode="numeric" value="' + j.days + '"></div></div>' +
      '<div class="field"><label class="lb" for="bNote">Why you are a good fit</label><textarea class="inp" id="bNote" placeholder="Share relevant work, your approach and questions. Minimum 40 characters. No contact details or links."></textarea></div>' +
      '<div class="brk"><div><span>Your price</span><span class="mono" id="bP">₹0</span></div><div><span>JobLancer commission (' + fee + '%)</span><span class="mono" id="bF">-₹0</span></div><div class="tot"><span>You receive</span><span class="mono" id="bR">₹0</span></div></div><div class="ferr" hidden></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><button class="btn" type="submit">Place bid</button><span class="muted" style="font-size:13px">' + u.bidsLeft + ' bids left this month</span></div></form>';
  }
  openPanel(h); calcBid();
}
function calcBid() {
  var f = $('form[data-form="bid"]'); if (!f) return;
  var amt = parseInt($('#bAmt').value.replace(/\D/g, ''), 10) || 0, fee = Math.round(amt * Number(f.dataset.fee) / 100);
  $('#bP').textContent = inr(amt * 100); $('#bF').textContent = '-' + inr(fee * 100); $('#bR').textContent = inr(Math.max(0, amt - fee) * 100);
}

/* ---------- thread ---------- */
var thr = { id: 0, last: 0, timer: null };
function stopThread() { if (thr.timer) { clearInterval(thr.timer); thr.timer = null; } }
async function openThread(bidId, title) {
  stopThread(); thr.id = bidId; thr.last = 0;
  var admin = S.user && S.user.role === 'admin';
  openPanel(panelHead('Messages', title) + '<div class="note fine">Keep all talk on JobLancer. Phone numbers, emails and chat apps are blocked. Links open up after escrow is funded.</div><div class="thread" id="thread"><div class="skeleton">Loading…</div></div>' +
    (admin ? '' : '<form class="sendrow" data-form="msg"><input class="inp" id="msgIn" maxlength="1000" placeholder="Write a message" autocomplete="off" aria-label="Message"><button class="btn" type="submit">Send</button></form><div class="ferr" hidden></div>'));
  try { await pullThread(true); thr.timer = setInterval(function () { pullThread(false).catch(function () {}); }, 6000); } catch (e) { panelError(e); }
}
async function pullThread(first) {
  var d = await api('GET', '/api/bids/' + thr.id + '/messages?after=' + (first ? 0 : thr.last)), box = $('#thread');
  if (!box) { stopThread(); return; }
  if (first) box.innerHTML = '';
  if (first && !d.messages.length) box.innerHTML = '<div class="empty" id="noMsg" style="padding:20px 0">No messages yet. Say hello.</div>';
  if (d.messages.length) { var nm = $('#noMsg'); if (nm) nm.remove(); }
  d.messages.forEach(function (m) { thr.last = Math.max(thr.last, m.id); var el = document.createElement('div'); el.className = 'msg' + (m.mine ? ' me' : ''); el.innerHTML = '<small>' + esc(m.name) + ' · ' + when(m.createdAt) + '</small>' + esc(m.body); box.appendChild(el); });
  if (d.messages.length) box.scrollTop = box.scrollHeight;
}

/* ---------- contracts ---------- */
async function openContract(id) {
  openPanel('<div class="skeleton">Loading…</div>');
  try { renderContract((await api('GET', '/api/contracts/' + id)).contract); } catch (e) { panelError(e); }
}
function renderContract(c) {
  var isC = c.role === 'client', h = panelHead(c.jobTitle, 'Contract #' + c.id) + '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">' + pill(CSTATUS, c.status) + '<span class="fine">with ' + esc(c.otherName) + ' · ' + c.days + ' days</span></div>';
  h += '<div class="brk"><div><span>Agreed price</span><span class="mono">' + inr(c.amountPaise) + '</span></div>' +
    (isC ? '<div><span>Payment protection (' + S.meta.escrowFeePct + '%)</span><span class="mono">' + inr(c.clientFeePaise) + '</span></div><div class="tot"><span>You pay into escrow</span><span class="mono">' + inr(c.totalPaise) + '</span></div>'
      : c.role === 'freelancer' ? '<div><span>JobLancer commission (' + c.commissionPct + '%)</span><span class="mono">-' + inr(c.commissionPaise) + '</span></div><div class="tot"><span>You receive</span><span class="mono">' + inr(c.receivePaise) + '</span></div>' : '') + '</div>';
  if (c.revisionNote && (c.status === 'funded')) h += '<div class="note"><b>Change requested:</b> ' + esc(c.revisionNote) + '</div>';
  if (c.deliveryNote) h += '<div class="card stack" style="gap:6px"><b>Delivery note</b><p class="desc">' + esc(c.deliveryNote) + '</p><span class="fine">Delivered ' + when(c.deliveredAt) + '</span></div>';
  var chat = '<button class="btn ghost sm" type="button" data-act="thread" data-id="' + c.bidId + '" data-title="' + esc(c.jobTitle) + '">Open messages</button>';
  var disp = '<button class="btn ghost sm" type="button" data-act="dispute-open" data-id="' + c.id + '">Raise a dispute</button>';
  if (c.status === 'awaiting_payment') {
    h += isC ? '<div class="paybox"><b>Fund escrow to start the work</b><span class="fine">Your money is held safely and released only when you approve the delivery.</span><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" type="button" data-act="pay-contract" data-id="' + c.id + '">Pay ' + inr(c.totalPaise) + ' into escrow</button><button class="btn ghost" type="button" data-act="cancel-contract" data-id="' + c.id + '">Cancel hire</button>' + chat + '</div></div>'
      : '<div class="note">Waiting for the client to fund escrow. You can start once the money is held.</div>' + chat;
  } else if (c.status === 'funded') {
    h += isC ? '<div class="okbox"><b>Escrow is funded.</b> The freelancer is working on it.</div><div style="display:flex;gap:8px;flex-wrap:wrap">' + chat + disp + '</div>'
      : '<form class="stack" data-form="deliver" data-id="' + c.id + '"><h3 class="sub">Deliver your work</h3><div class="field"><label class="lb" for="dNote">Delivery note</label><textarea class="inp" id="dNote" placeholder="Describe what you are delivering. You can paste a link to the files here."></textarea></div><div class="ferr" hidden></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" type="submit">Submit delivery</button>' + chat + disp + '</div></form>';
  } else if (c.status === 'delivered') {
    h += isC ? '<div class="note">Review the work. If you do nothing, payment is released automatically on <b>' + day(c.autoReleaseAt) + '</b>.</div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" type="button" data-act="approve" data-id="' + c.id + '">Approve and release payment</button><button class="btn ghost" type="button" data-act="rev-open" data-id="' + c.id + '">Request changes (' + (3 - c.revisions) + ' left)</button>' + chat + disp + '</div><div id="subForm"></div>'
      : '<div class="okbox">Delivered. Waiting for the client to approve.</div><div style="display:flex;gap:8px;flex-wrap:wrap">' + chat + disp + '</div><div id="subForm"></div>';
  } else if (c.status === 'disputed') {
    h += '<div class="alert"><b>Under review.</b> JobLancer support is reviewing this dispute and will decide within 3 working days.' + (c.disputeReason ? '<br>Reason: ' + esc(c.disputeReason) : '') + '</div>' + chat;
  } else if (c.status === 'released') {
    h += '<div class="okbox">Work approved on ' + when(c.releasedAt) + '.' + (c.role === 'freelancer' ? ' Payout to your UPI is <b>' + (c.payoutStatus === 'paid' ? 'done' : 'in progress') + '</b>.' : '') + '</div>' + chat;
  } else if (c.status === 'refunded') h += '<div class="note">This contract was refunded to the client. Refund is <b>' + (c.payoutStatus === 'paid' ? 'done' : 'in progress') + '</b>.</div>';
  openPanel(h);
}
function mockPayPanel(o, title) {
  return new Promise(function (resolve) {
    openPanel(panelHead('Test payment') + '<div class="paybox"><b>' + esc(title) + '</b><div class="mono" style="font-size:26px">' + inr(o.amountPaise) + '</div><p class="fine">Test mode. No real money moves. When the live payment gateway is connected, this opens the Razorpay window for UPI, cards and net banking.</p><div style="display:flex;gap:8px"><button class="btn" type="button" id="mockOk">Pay (test)</button><button class="btn ghost" type="button" id="mockNo">Cancel</button></div></div>');
    $('#mockOk').onclick = async function () {
      try { resolve(await api('POST', '/api/payments/verify', { paymentId: o.paymentId, razorpay_signature: 'mock-ok' })); } catch (e) { toast(e.message, true); resolve(null); }
    };
    $('#mockNo').onclick = function () { resolve(null); };
  });
}
function loadRzp() { return new Promise(function (res, rej) { if (window.Razorpay) return res(); var s = document.createElement('script'); s.src = 'https://checkout.razorpay.com/v1/checkout.js'; s.onload = res; s.onerror = function () { rej(new Error('Could not load the payment window. Check your connection.')); }; document.head.appendChild(s); }); }
async function payFlow(o, title) {
  if (o.mode !== 'razorpay') return mockPayPanel(o, title);
  await loadRzp();
  return new Promise(function (resolve) {
    var rz = new window.Razorpay({ key: o.keyId, amount: o.amountPaise, currency: 'INR', name: 'JobLancer', description: title, order_id: o.orderId, prefill: { name: o.name, email: o.email, contact: o.phone }, theme: { color: '#0A7B66' },
      handler: async function (resp) { try { resolve(await api('POST', '/api/payments/verify', { paymentId: o.paymentId, razorpay_payment_id: resp.razorpay_payment_id, razorpay_signature: resp.razorpay_signature })); } catch (e) { toast(e.message, true); resolve(null); } },
      modal: { ondismiss: function () { resolve(null); } } });
    rz.open();
  });
}

/* ======================= POST A JOB ======================= */
R.post = function () {
  var u = S.user;
  if (!u) return gate('Create a client account to post a job', 'It takes a minute. You will verify your mobile, email and PAN so freelancers can trust your jobs.', 'client');
  if (u.role !== 'client') return $('#app').innerHTML = '<div class="wrap sec"><div class="card" style="max-width:560px"><h2>Only clients can post jobs</h2><p class="muted" style="margin-top:8px">You are logged in as a ' + esc(u.role) + '. To post jobs, log out and create a client account with a different email and mobile number.</p></div></div>';
  if (!u.canPost) {
    var row = function (ok, t) { return '<div class="check ' + (ok ? 'on' : '') + '"><b>✓</b>' + t + '</div>'; };
    return $('#app').innerHTML = '<div class="wrap sec"><div class="card stack" style="max-width:560px"><h2>Finish verification to post jobs</h2><div class="stack" style="gap:8px">' + row(u.phoneVerified, 'Mobile number verified') + row(u.emailVerified, 'Email verified') + row(u.panStatus === 'approved', u.panStatus === 'pending' ? 'PAN submitted, waiting for approval' : 'PAN verified') + '</div><div><button class="btn" type="button" data-go="account">Continue verification</button></div></div></div>';
  }
  S.post = { cat: '', skills: [] };
  var cap = u.completed ? '' : ' New clients can post jobs up to ₹25,000 until the first project is completed.';
  $('#app').innerHTML = '<div class="wrap sec"><div class="sec-h"><div><p class="eyebrow">For clients</p><h2>Post a job</h2></div></div><div class="cols"><form class="card stack" data-form="post" novalidate>' +
    '<div class="field"><label class="lb" for="pTitle">Job title</label><input class="inp" id="pTitle" maxlength="90" placeholder="e.g. Build a Shopify store for a handloom brand"></div>' +
    '<div class="field"><label class="lb" for="pCat">Category</label><select class="inp" id="pCat">' + catOptions('', 'Select a category') + '</select></div>' +
    '<div class="field"><label class="lb">Skills needed (up to 5)</label><div class="chips" id="pSkills"><span class="hint">Choose a category first.</span></div></div>' +
    '<div class="field"><label class="lb" for="pDesc">What needs to be done</label><textarea class="inp" id="pDesc" placeholder="Describe the deliverables, format, references and what a finished job looks like. Minimum 60 characters."></textarea><p class="hint"><span id="descCount">0</span> characters. Phone numbers, emails, links and chat contacts are blocked.</p><div class="hint" id="scanHint" style="color:var(--bad)"></div></div>' +
    '<div class="row2"><div class="field"><label class="lb" for="pBudget">Fixed budget (₹)</label><input class="inp mono" id="pBudget" inputmode="numeric" placeholder="15000"></div><div class="field"><label class="lb" for="pDays">Deadline (days)</label><input class="inp mono" id="pDays" inputmode="numeric" placeholder="14"></div></div>' +
    '<div class="ferr" hidden></div><div><button class="btn" type="submit">Publish job</button></div></form>' +
    '<aside class="card stack aside"><h3 class="sub">How hiring works</h3><ol class="steps"><li class="done"><span class="dot">✓</span><span>Post the job<small>Free. Goes live immediately.</small></span></li><li><span class="dot"></span><span>Review bids and chat<small>Only skill-verified freelancers can bid.</small></span></li><li><span class="dot"></span><span>Hire and fund escrow<small>You pay the price plus ' + S.meta.escrowFeePct + '% protection fee.</small></span></li><li><span class="dot"></span><span>Approve the work<small>Money is released to the freelancer.</small></span></li></ol><p class="hint">' + cap + '</p></aside></div></div>';
};

/* ======================= DASHBOARD ======================= */
R.dashboard = async function () {
  var u = S.user;
  if (!u) return gate('Log in to see your dashboard', 'Your jobs, bids and contracts live here.');
  if (u.role === 'admin') return go('admin');
  $('#app').innerHTML = '<div class="wrap sec"><div class="skeleton">Loading your dashboard…</div></div>';
  try {
    var cs = (await api('GET', '/api/my/contracts')).contracts, h, stats;
    if (u.role === 'client') {
      var jobs = (await api('GET', '/api/my/jobs')).jobs;
      var spent = cs.filter(function (c) { return c.status === 'released'; }).reduce(function (a, c) { return a + c.totalPaise; }, 0);
      stats = [[jobs.filter(function (j) { return j.status === 'open'; }).length, 'Open jobs'], [cs.filter(function (c) { return ['funded', 'delivered', 'awaiting_payment', 'disputed'].indexOf(c.status) >= 0; }).length, 'Active contracts'], [cs.filter(function (c) { return c.status === 'released'; }).length, 'Completed'], [inr(spent), 'Total spent']];
      h = '<div class="sec-h"><div><p class="eyebrow">Client</p><h2>Your dashboard</h2></div><button class="btn" type="button" data-go="post">Post a job</button></div>' + statRow(stats) + '<h3 class="sub" style="margin-bottom:12px">Your jobs</h3><div class="list">' +
        (jobs.length ? jobs.map(function (j) { return '<div class="item"><div class="main"><h4>' + esc(j.title) + '</h4><div class="meta"><span>' + inr(j.budgetPaise) + '</span><span>' + pl(j.bids, 'bid') + '</span><span>' + ago(j.createdAt) + '</span>' + pill({ open: ['Open', 'go'], in_progress: ['In progress', 'go'], completed: ['Completed', ''], closed: ['Closed', ''] }, j.status) + '</div></div><div class="acts"><button class="btn sm" type="button" data-act="job" data-id="' + j.id + '">' + (j.status === 'open' ? 'View bids' : 'Open') + '</button>' + (j.contract ? '<button class="btn ghost sm" type="button" data-act="contract" data-id="' + j.contract.id + '">Contract</button>' : '') + '</div></div>'; }).join('') : '<div class="empty">You have not posted a job yet.</div>') + '</div>';
    } else {
      var bids = (await api('GET', '/api/my/bids')).bids, earned = cs.filter(function (c) { return c.status === 'released'; }).reduce(function (a, c) { return a + c.receivePaise; }, 0);
      stats = [[u.planName, 'Plan'], [u.bidsLeft, 'Bids left this month'], [cs.filter(function (c) { return ['funded', 'delivered', 'awaiting_payment', 'disputed'].indexOf(c.status) >= 0; }).length, 'Active contracts'], [inr(earned), 'Total earned']];
      h = '<div class="sec-h"><div><p class="eyebrow">Freelancer</p><h2>Your dashboard</h2></div><button class="btn" type="button" data-go="jobs">Find work</button></div>' + statRow(stats) + '<h3 class="sub" style="margin-bottom:12px">Your bids</h3><div class="list">' +
        (bids.length ? bids.map(function (b) { return '<div class="item"><div class="main"><h4>' + esc(b.jobTitle) + '</h4><div class="meta"><span>' + inr(b.amountPaise) + '</span><span>' + b.days + ' days</span><span>' + ago(b.createdAt) + '</span>' + pill(BSTATUS, b.status) + '</div></div><div class="acts"><button class="btn ghost sm" type="button" data-act="thread" data-id="' + b.id + '" data-title="' + esc(b.jobTitle) + '">Messages</button>' + (b.contractId ? '<button class="btn sm" type="button" data-act="contract" data-id="' + b.contractId + '">Contract</button>' : '<button class="btn ghost sm" type="button" data-act="job" data-id="' + b.jobId + '">Job</button>') + '</div></div>'; }).join('') : '<div class="empty">You have not placed a bid yet. ' + (u.canBid ? 'Browse jobs and send your first proposal.' : 'Finish verification to start bidding.') + '</div>') + '</div>';
    }
    h += '<h3 class="sub" style="margin:28px 0 12px">Contracts</h3><div class="list">' + (cs.length ? cs.map(function (c) {
      var money = c.role === 'client' ? inr(c.totalPaise) + ' incl. fee' : inr(c.receivePaise) + ' after commission';
      return '<div class="item"><div class="main"><h4>' + esc(c.jobTitle) + '</h4><div class="meta"><span>with ' + esc(c.otherName) + '</span><span>' + money + '</span>' + pill(CSTATUS, c.status) + '</div></div><div class="acts"><button class="btn sm" type="button" data-act="contract" data-id="' + c.id + '">' + (c.role === 'client' && c.status === 'awaiting_payment' ? 'Pay now' : c.role === 'client' && c.status === 'delivered' ? 'Review work' : c.role === 'freelancer' && c.status === 'funded' ? 'Deliver' : 'Open') + '</button></div></div>';
    }).join('') : '<div class="empty">No contracts yet. They appear when a client hires a freelancer.</div>') + '</div>';
    $('#app').innerHTML = '<div class="wrap sec">' + h + '</div>';
  } catch (e) { $('#app').innerHTML = '<div class="wrap sec"><div class="alert">' + esc(e.message) + '</div></div>'; }
};
function statRow(a) { return '<div class="statrow">' + a.map(function (s) { return '<div class="stat"><b>' + esc(s[0]) + '</b><span>' + esc(s[1]) + '</span></div>'; }).join('') + '</div>'; }

/* ======================= ACCOUNT ======================= */
function otpRow(kind, label, value, verified) {
  return '<div class="vrow ' + (verified ? 'ok' : '') + '" data-otp="' + kind + '"><div class="vhead"><span>' + label + ': ' + esc(value) + '</span><span class="vstate">' + (verified ? 'Verified ✓' : 'Not verified') + '</span></div>' +
    (verified ? '' : '<div class="vbody" data-stage="enter"><button class="btn ghost sm" type="button" data-act="otp-send" data-kind="' + kind + '">Send code</button></div><div class="vbody" data-stage="code" hidden><input class="inp mono" data-f="code" inputmode="numeric" maxlength="6" placeholder="6-digit code" aria-label="' + label + ' code" autocomplete="one-time-code"><button class="btn sm" type="button" data-act="otp-verify" data-kind="' + kind + '">Confirm</button></div><p class="hint" data-f="hint"></p>') + '</div>';
}
R.account = async function () {
  var u = S.user;
  if (!u) return gate('Log in to manage your account', 'Verification, profile and security settings are here.');
  paintBanner();
  var h = '<div class="wrap sec"><div class="sec-h"><div><p class="eyebrow">' + esc(u.role) + '</p><h2>Your account</h2></div></div><div class="stack" style="max-width:820px">';
  h += '<div class="card stack"><h3 class="sub">Contact verification</h3>' + otpRow('phone', 'Mobile', u.phone || '', u.phoneVerified) + otpRow('email', 'Email', u.email, u.emailVerified) + '</div>';
  if (u.role === 'client') {
    var st = u.panStatus;
    h += '<div class="card stack"><h3 class="sub">PAN verification</h3>' + (st === 'approved' ? '<div class="okbox">Your PAN is verified. You can post jobs.</div>' : st === 'pending' ? '<div class="note">Your PAN is under review. This usually takes less than a day. You will be able to post once it is approved.</div>' :
      (st === 'rejected' ? '<div class="alert">Your PAN was not approved: ' + esc(u.panNote || 'details did not match') + '. Please submit again.</div>' : '') +
      '<form class="stack" data-form="pan" novalidate><div class="row2"><div class="field"><label class="lb" for="panName">Name as on PAN</label><input class="inp" id="panName" value="' + esc(u.name) + '"></div><div class="field"><label class="lb" for="panNo">PAN number</label><input class="inp mono" id="panNo" maxlength="10" placeholder="ABCDE1234F" style="text-transform:uppercase"></div></div><p class="hint">Used only to confirm you are a real person or business. It is stored encrypted and never shown to freelancers.</p><div class="ferr" hidden></div><div><button class="btn" type="submit">Submit PAN</button></div></form>') + '</div>';
  } else if (u.role === 'freelancer') {
    h += '<div class="card stack" id="examCard"><div class="skeleton">Loading exam status…</div></div><div class="card stack" id="profCard"></div>';
  }
  h += '<div class="card stack"><h3 class="sub">Change password</h3><form class="stack" data-form="pw" novalidate><div class="row2"><div class="field"><label class="lb" for="pwC">Current password</label><input class="inp" id="pwC" type="password" autocomplete="current-password"></div><div class="field"><label class="lb" for="pwN">New password</label><input class="inp" id="pwN" type="password" autocomplete="new-password"></div></div><div class="ferr" hidden></div><div><button class="btn ghost" type="submit">Update password</button></div></form></div>';
  h += '</div></div>';
  $('#app').innerHTML = h;
  if (u.role === 'freelancer') { paintProfile(); await loadExamCard(); }
};
function paintProfile() {
  var u = S.user, c = catByName(u.mainCategory) || S.meta.cats[0], box = $('#profCard'); if (!box) return;
  S.prof = { skills: u.skills.slice() };
  box.innerHTML = '<h3 class="sub">Your profile</h3><form class="stack" data-form="profile" novalidate><div class="field"><label class="lb" for="prCat">Main field</label><select class="inp" id="prCat">' + catOptions(u.mainCategory) + '</select></div><div class="field"><label class="lb">Skills (up to 8)</label><div class="chips" id="prSkills"></div></div>' +
    '<div class="field"><label class="lb" for="prBio">Short bio</label><textarea class="inp" id="prBio" maxlength="500" placeholder="Your experience in two or three lines. No contact details.">' + esc(u.bio) + '</textarea></div>' +
    '<div class="field"><label class="lb" for="prUpi">UPI ID for payouts</label><input class="inp" id="prUpi" value="' + esc(u.upi) + '" placeholder="name@okaxis"><p class="hint">Your earnings are sent here after the client approves the work.</p></div><div class="ferr" hidden></div><div><button class="btn" type="submit">Save profile</button></div></form>';
  bindChips($('#prSkills'), c.s, S.prof.skills, 8);
  $('#prCat').onchange = function () { bindChips($('#prSkills'), catByName($('#prCat').value).s, S.prof.skills, 8); };
}
async function loadExamCard() {
  var box = $('#examCard'); if (!box) return;
  try {
    var d = await api('GET', '/api/exam/status');
    if (d.active) { startExam(d.active); return; }
    var u = S.user, has = {}; d.badges.forEach(function (b) { has[b.category] = b; });
    var wait = d.nextAt > Date.now() ? '<div class="note">Your next exam attempt opens in about ' + Math.ceil((d.nextAt - Date.now()) / 3600000) + ' hours.</div>' : '';
    box.innerHTML = '<h3 class="sub">Skill exams</h3><p class="muted">Pass the exam for a field to bid on jobs in it. ' + S.meta.exam.questions + ' questions, ' + S.meta.exam.minutes + ' minutes, pass mark ' + S.meta.exam.pass + '. Questions are shuffled for every attempt. Leaving the tab twice ends the exam, and a failed attempt can be retried after ' + S.meta.exam.cooldownHours + ' hours.</p>' + wait +
      '<div class="catcards">' + S.meta.cats.map(function (c) {
        var b = has[c.n]; return '<div class="catcard ' + (b ? 'ok' : '') + '" id="cc-' + esc(c.n.replace(/\W/g, '')) + '"><b>' + esc(c.n) + '</b>' + (b ? '<span class="badge">' + SHIELD + 'Verified · ' + b.score + '/' + b.total + '</span>' : '<button class="btn sm' + (c.n === u.mainCategory ? '' : ' ghost') + '" type="button" data-act="exam-start" data-cat="' + esc(c.n) + '"' + (d.nextAt > Date.now() ? ' disabled' : '') + '>Take exam</button>') + '</div>';
      }).join('') + '</div><div class="ferr" hidden></div>';
    if (S.examCat) { var el = $('#cc-' + S.examCat.replace(/\W/g, '')); if (el) el.scrollIntoView({ block: 'center' }); S.examCat = ''; }
  } catch (e) { box.innerHTML = '<div class="alert">' + esc(e.message) + '</div>'; }
}

/* ---------- exam ---------- */
var examTimer = null;
function stopExamTimer() { if (examTimer) { clearInterval(examTimer); examTimer = null; } }
function startExam(att) {
  S.exam = { att: att, answers: new Array(att.total).fill(null), i: 0, offset: att.now - Date.now(), done: false };
  renderExam(); stopExamTimer(); examTimer = setInterval(tickExam, 500);
}
function tickExam() {
  var ex = S.exam; if (!ex || ex.done) return stopExamTimer();
  var left = Math.max(0, ex.att.endsAt - (Date.now() + ex.offset)), m = Math.floor(left / 60000), s = Math.floor(left % 60000 / 1000), t = $('#timerTxt');
  if (t) t.textContent = m + ':' + (s < 10 ? '0' : '') + s;
  if (left <= 0) submitExam();
}
function renderExam() {
  var ex = S.exam, q = ex.att.questions[ex.i], total = ex.att.total, card = $('#examCard') || $('#app');
  if (!$('#examCard')) { $('#app').innerHTML = '<div class="wrap sec"><div class="card stack" id="examCard" style="max-width:760px;margin-inline:auto"></div></div>'; }
  $('#examCard').innerHTML = '<div style="display:flex;justify-content:space-between;gap:10px"><span class="eyebrow">' + esc(ex.att.category) + ' exam · Question ' + (ex.i + 1) + ' of ' + total + '</span><span class="timer" id="timerTxt">--:--</span></div><div class="prog"><i style="width:' + (ex.i / total * 100) + '%"></i></div><h3 class="q">' + esc(q.q) + '</h3><div>' +
    q.o.map(function (o, i) { return '<label class="opt"><input type="radio" name="opt" value="' + i + '"' + (ex.answers[ex.i] === i ? ' checked' : '') + '><span>' + esc(o) + '</span></label>'; }).join('') + '</div><div class="ferr" hidden></div><div><button class="btn" type="button" data-act="exam-next"' + (ex.answers[ex.i] === null ? ' disabled' : '') + '>' + (ex.i === total - 1 ? 'Submit exam' : 'Next question') + '</button></div>';
  tickExam();
}
async function submitExam() {
  var ex = S.exam; if (!ex || ex.done) return; ex.done = true; stopExamTimer();
  try { var r = await api('POST', '/api/exam/' + ex.att.attemptId + '/submit', { answers: ex.answers }); showExamResult(r); if (r.passed) refreshMe(); }
  catch (e) { showExamResult({ passed: false, error: e.message }); }
}
function showExamResult(r) {
  S.exam = null; stopExamTimer();
  var html;
  if (r.passed) html = '<div class="score">' + r.score + ' / ' + r.total + '</div><h3>You passed the ' + esc(r.category) + ' exam</h3><p class="muted">You can now bid on ' + esc(r.category) + ' jobs. Pass more exams to unlock more categories.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" type="button" data-go="jobs">Browse jobs</button><button class="btn ghost" type="button" data-go="account">Back to my account</button></div>';
  else html = '<div class="score bad">' + (r.score !== undefined ? r.score + ' / ' + r.total : '—') + '</div><h3>Not passed this time</h3><p class="muted">' + esc(r.error || (r.expired ? 'Time ran out before you submitted.' : r.ended ? 'The exam ended because you left the tab twice.' : 'You needed ' + r.pass + ' correct answers to pass.')) + ' You can try again in ' + S.meta.exam.cooldownHours + ' hours with a fresh set of questions.</p><div><button class="btn ghost" type="button" data-go="account">Back to my account</button></div>';
  $('#app').innerHTML = '<div class="wrap sec"><div class="card stack" style="max-width:560px;margin-inline:auto">' + html + '</div></div>';
  window.scrollTo(0, 0);
}
document.addEventListener('visibilitychange', async function () {
  var ex = S.exam; if (!ex || ex.done || !document.hidden) return;
  try { var r = await api('POST', '/api/exam/' + ex.att.attemptId + '/switch'); if (r.ended) { ex.done = true; showExamResult({ passed: false, ended: true }); } else toast('Warning: leaving this tab again will end your exam.', true); } catch (e) { /* ignore */ }
});

/* ======================= PRICING ======================= */
R.pricing = function () {
  var u = S.user, v = 20000;
  $('#app').innerHTML = '<div class="wrap sec"><div class="sec-h"><div><p class="eyebrow">Memberships for freelancers</p><h2>Bid more, keep more</h2></div></div><p class="muted" style="max-width:62ch;margin-bottom:18px">Commission is taken only from payments you actually receive. A higher plan gives you more bids each month and a lower commission. Clients never pay a subscription. They pay a ' + S.meta.escrowFeePct + '% payment protection fee on each hire.</p>' +
    '<div class="card stack" style="margin-bottom:18px"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><label class="lb" for="calc" style="margin:0">If your project is worth</label><b class="mono" id="calcVal">' + inr(v * 100) + '</b></div><input type="range" id="calc" min="1000" max="200000" step="500" value="' + v + '"></div><div class="plans" id="plans"></div><p class="hint" style="margin-top:14px">Plans last 30 days from purchase. Bids reset every 30 days.</p></div>';
  paintPlans();
};
function paintPlans() {
  var u = S.user, v = parseInt($('#calc').value, 10); $('#calcVal').textContent = inr(v * 100);
  var feats = { free: ['10 bids a month', '15% commission', 'Skill-verified badge'], pro: ['40 bids a month', '10% commission', 'Higher placement in bids list', 'Priority support'], elite: ['120 bids a month', '5% commission', 'Featured profile badge', 'Faster payouts'] };
  $('#plans').innerHTML = S.meta.plans.map(function (p) {
    var keep = v - Math.round(v * p.feePct / 100), cur = u && u.role === 'freelancer' && u.plan === p.key, dis = u && u.role !== 'freelancer';
    var label = cur ? 'Current plan' : dis ? 'For freelancers' : !u ? 'Sign up to start' : (p.pricePaise ? 'Choose ' + p.name : 'Switch to Starter');
    return '<div class="card plan' + (p.key === 'pro' ? ' pop' : '') + '">' + (p.key === 'pro' ? '<span class="poptag">Most chosen</span>' : '') + '<h3 style="font-size:1.2rem">' + p.name + '</h3><div class="price">' + (p.pricePaise ? inr(p.pricePaise) + ' <small>/ month</small>' : 'Free') + '</div><ul>' + feats[p.key].map(function (f) { return '<li>' + f + '</li>'; }).join('') + '</ul><div class="keep">You keep <b>' + inr(keep * 100) + '</b> from ' + inr(v * 100) + '</div><button class="btn' + (cur ? ' ghost' : '') + '" type="button" data-act="plan" data-plan="' + p.key + '"' + (cur || dis ? ' disabled' : '') + '>' + label + '</button>' + (cur && u.planExpiresAt ? '<p class="fine">Active until ' + day(u.planExpiresAt) + '</p>' : '') + '</div>';
  }).join('');
}

/* ======================= TRUST ======================= */
R.trust = function () {
  $('#app').innerHTML = '<div class="wrap sec stack" style="gap:28px"><div class="sec-h" style="margin:0"><div><p class="eyebrow">Trust &amp; safety</p><h2>How JobLancer keeps both sides safe</h2></div></div>' +
    (S.meta.paymentsMode === 'mock' ? '<div class="note">Test mode: payments are simulated. No real money moves.</div>' : '') +
    '<div><h3 style="margin-bottom:14px">How a payment is protected</h3><div class="flow"><div><h4>Client funds escrow</h4><p>After hiring, the client pays into escrow. The freelancer can see the money is held before starting.</p></div><div><h4>Freelancer delivers</h4><p>Files and messages stay on JobLancer, so there is a record of what was agreed.</p></div><div><h4>Client reviews</h4><p>Up to 3 change requests. If the client does not respond in 5 days, payment is released automatically.</p></div><div><h4>Payment is released</h4><p>The freelancer receives the price minus commission. Either side can raise a dispute while money is in escrow.</p></div></div></div>' +
    '<div class="grid3"><div class="card"><h3>Checks on clients</h3><ul><li>Mobile OTP, email code and PAN check before the first job.</li><li>Disposable email addresses are rejected. One PAN, one account.</li><li>New clients are capped at ₹25,000 per job until one project completes.</li><li>Work starts only after escrow is funded.</li><li>Job text is scanned for scam patterns before it goes live.</li></ul></div>' +
    '<div class="card"><h3>Checks on freelancers</h3><ul><li>Verified mobile number and email.</li><li>A timed skill exam for each category, graded on the server.</li><li>Shuffled questions, a 24-hour retake wait, and leaving the tab twice ends the exam.</li><li>You can bid only in categories you have passed.</li></ul></div>' +
    '<div class="card"><h3>If something goes wrong</h3><ul><li>Either side can raise a dispute while money is in escrow.</li><li>Messages are kept as evidence.</li><li>JobLancer reviews and either releases the payment or refunds the client.</li><li>Accounts with repeated reports are suspended.</li></ul></div></div>' +
    '<div class="card"><h3 style="margin-bottom:10px">What is blocked automatically</h3><div class="tbl-wrap"><table><thead><tr><th>Pattern</th><th>Why</th></tr></thead><tbody><tr><td>Phone numbers, emails and chat links in jobs, proposals and early messages</td><td>Keeps deals on the platform, where escrow and disputes work.</td></tr><tr><td>Asking to pay or be paid outside JobLancer</td><td>The most common way freelancers lose money.</td></tr><tr><td>Registration fees, deposits, refundable charges</td><td>Real clients never charge freelancers to start work.</td></tr><tr><td>Investment, crypto and guaranteed-income language</td><td>Not a freelance job. Usually a scam.</td></tr></tbody></table></div></div></div>';
};

/* ======================= ADMIN ======================= */
R.admin = function () {
  var u = S.user;
  if (!u || u.role !== 'admin') return gate('Admin only', 'Log in with the admin account.');
  var tabs = [['overview', 'Overview'], ['kyc', 'PAN review'], ['payouts', 'Payouts'], ['disputes', 'Disputes'], ['users', 'Users'], ['audit', 'Activity']];
  $('#app').innerHTML = '<div class="wrap sec"><div class="sec-h"><div><p class="eyebrow">Admin</p><h2>Control panel</h2></div></div><div class="tabsbar" id="atabs">' + tabs.map(function (t) { return '<button type="button" data-act="atab" data-t="' + t[0] + '" aria-pressed="' + (S.atab === t[0]) + '">' + t[1] + '</button>'; }).join('') + '</div><div id="abody"><div class="skeleton">Loading…</div></div></div>';
  loadAdmin();
};
async function loadAdmin() {
  var b = $('#abody'), t = S.atab;
  try {
    if (t === 'overview') {
      var s = await api('GET', '/api/admin/summary'), c = s.contracts, n = function (k) { return c[k] || 0; };
      var pend = s.payoutsPending.map(function (p) { return p.n + ' to ' + p.payout_to + ' (' + inr(p.paise) + ')'; }).join(', ') || 'none';
      b.innerHTML = statRow([[s.users.clients, 'Clients'], [s.users.freelancers, 'Freelancers'], [s.jobsOpen, 'Open jobs'], [n('funded') + n('delivered'), 'Contracts in progress'], [inr(s.releasedPaise), 'Released to freelancers (gross)'], [inr(s.commissionPaise), 'Commission earned'], [inr(s.feesPaise), 'Protection fees'], [inr(s.planRevenuePaise), 'Membership revenue']]) +
        '<div class="list"><div class="item"><div class="main"><h4>Needs your attention</h4><div class="meta"><span>PAN reviews: <b>' + s.panPending + '</b></span><span>Open disputes: <b>' + s.openDisputes + '</b></span><span>Pending payouts: <b>' + esc(pend) + '</b></span><span>Payments to refund: <b>' + s.needsRefund.length + '</b></span></div></div></div></div>' +
        (s.needsRefund.length ? '<h3 class="sub" style="margin:24px 0 10px">Payments to refund</h3><div class="list">' + s.needsRefund.map(function (p) { return '<div class="item"><div class="main"><h4>' + inr(p.amount_paise) + ' (payment ' + esc(p.provider_payment_id || '') + ')</h4><div class="meta"><span>Contract #' + esc(p.ref) + ' was cancelled before this payment arrived.</span></div></div><div class="acts inl"><input class="inp" id="rf' + p.id + '" placeholder="Refund reference"><button class="btn sm" type="button" data-act="refunded" data-id="' + p.id + '">Mark refunded</button></div></div>'; }).join('') + '</div>' : '');
    } else if (t === 'kyc') {
      var k = (await api('GET', '/api/admin/pan')).items;
      b.innerHTML = k.length ? '<div class="list">' + k.map(function (x) { return '<div class="item"><div class="main"><h4>' + esc(x.name) + ' <span class="fine">(' + esc(x.email) + ', ' + esc(x.phone) + ')</span></h4><div class="meta"><span>Name on PAN: <b>' + esc(x.panName) + '</b></span><span>PAN: <b class="mono">' + esc(x.pan) + '</b></span><span>' + when(x.createdAt) + '</span></div></div><div class="acts inl"><button class="btn sm" type="button" data-act="pan-ok" data-id="' + x.id + '">Approve</button><input class="inp" id="pn' + x.id + '" placeholder="Reason if rejecting"><button class="btn ghost sm" type="button" data-act="pan-no" data-id="' + x.id + '">Reject</button></div></div>'; }).join('') + '</div><p class="hint" style="margin-top:12px">Check the PAN and name on the Income Tax e-filing portal (Verify your PAN) before approving.</p>' : '<div class="empty">No PAN waiting for review.</div>';
    } else if (t === 'payouts') {
      var cs = (await api('GET', '/api/admin/contracts?payout=pending')).contracts;
      b.innerHTML = cs.length ? '<div class="list">' + cs.map(function (x) { return '<div class="item"><div class="main"><h4>' + esc(x.jobTitle) + ' <span class="fine">#' + x.id + '</span></h4><div class="meta"><span>Pay <b>' + inr(x.payoutPaise) + '</b> to <b>' + esc(x.payoutTo) + '</b></span><span>' + (x.payoutTo === 'freelancer' ? 'Freelancer: ' + esc(x.freelancer) + ', UPI: <b class="mono">' + esc(x.freelancerUpi || 'not set') + '</b>' : 'Client: ' + esc(x.client) + ' (' + esc(x.clientEmail) + '). Refund via payment gateway.') + '</span></div></div><div class="acts inl"><input class="inp" id="ut' + x.id + '" placeholder="UTR / reference"><button class="btn sm" type="button" data-act="paid" data-id="' + x.id + '">Mark paid</button></div></div>'; }).join('') + '</div>' : '<div class="empty">No payouts waiting.</div>';
    } else if (t === 'disputes') {
      var d = (await api('GET', '/api/admin/disputes')).disputes;
      b.innerHTML = d.length ? '<div class="list">' + d.map(function (x) { return '<div class="item" style="align-items:flex-start"><div class="main"><h4>' + esc(x.jobTitle) + ' <span class="fine">contract #' + x.contractId + ' · ' + inr(x.amountPaise) + '</span></h4><div class="meta"><span>Raised by ' + esc(x.raisedBy) + ' (' + esc(x.raisedRole) + ')</span><span>' + when(x.createdAt) + '</span></div><p style="margin-top:8px;white-space:pre-wrap">' + esc(x.reason) + '</p>' + (x.deliveryNote ? '<p class="fine" style="margin-top:6px;white-space:pre-wrap">Delivery note: ' + esc(x.deliveryNote) + '</p>' : '') + '</div><div class="stack" style="gap:8px;min-width:240px"><button class="btn ghost sm" type="button" data-act="thread" data-id="' + x.bidId + '" data-title="' + esc(x.jobTitle) + '">Read messages</button><input class="inp" id="dn' + x.id + '" placeholder="Decision note"><div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm" type="button" data-act="resolve" data-id="' + x.id + '" data-a="release">Pay freelancer</button><button class="btn ghost sm" type="button" data-act="resolve" data-id="' + x.id + '" data-a="refund">Refund client</button></div></div></div>'; }).join('') + '</div>' : '<div class="empty">No open disputes.</div>';
    } else if (t === 'users') {
      b.innerHTML = '<div class="toolbar"><input class="inp" id="uq" type="search" placeholder="Search name, email or mobile"><select class="inp" id="ur"><option value="">All roles</option><option value="client">Clients</option><option value="freelancer">Freelancers</option></select></div><div class="tbl-wrap card" style="padding:0" id="utable"></div>';
      await loadUsers();
    } else if (t === 'audit') {
      var a = (await api('GET', '/api/admin/audit')).items;
      b.innerHTML = '<div class="tbl-wrap card" style="padding:0"><table><thead><tr><th>When</th><th>User</th><th>Action</th><th>Detail</th><th>IP</th></tr></thead><tbody>' + a.map(function (x) { return '<tr><td>' + when(x.created_at) + '</td><td>' + esc(x.email || '') + '</td><td>' + esc(x.action) + '</td><td>' + esc(x.detail || '') + '</td><td class="mono">' + esc(x.ip || '') + '</td></tr>'; }).join('') + '</tbody></table></div>';
    }
  } catch (e) { b.innerHTML = '<div class="alert">' + esc(e.message) + '</div>'; }
}
async function loadUsers() {
  var q = $('#uq') ? $('#uq').value : '', r = $('#ur') ? $('#ur').value : '', qs = new URLSearchParams();
  if (q) qs.set('q', q); if (r) qs.set('role', r);
  var us = (await api('GET', '/api/admin/users?' + qs)).users;
  $('#utable').innerHTML = '<table><thead><tr><th>Name</th><th>Role</th><th>Contact</th><th>Checks</th><th>Plan</th><th>Joined</th><th></th></tr></thead><tbody>' + us.map(function (x) {
    return '<tr><td>' + esc(x.name) + (x.status === 'banned' ? ' <span class="pill stop">Suspended</span>' : '') + '</td><td>' + esc(x.role) + '</td><td>' + esc(x.email) + '<br><span class="fine">' + esc(x.phone || '') + '</span></td><td>' + (x.phone_verified ? '📱' : '·') + ' ' + (x.email_verified ? '✉️' : '·') + ' ' + (x.role === 'client' ? 'PAN: ' + esc(x.pan_status) : '') + '</td><td>' + esc(x.plan) + '</td><td>' + day(x.created_at) + '</td><td>' + (x.role === 'admin' ? '' : '<button class="btn ghost sm" type="button" data-act="ban" data-id="' + x.id + '" data-s="' + (x.status === 'banned' ? 'active' : 'banned') + '">' + (x.status === 'banned' ? 'Restore' : 'Suspend') + '</button>') + '</td></tr>';
  }).join('') + '</tbody></table>';
}

/* ======================= other forms ======================= */
async function otherForms(kind, form, btn, err) {
  if (kind === 'post') {
    var P = S.post, title = $('#pTitle').value, desc = $('#pDesc').value;
    var local = scan(title + '\n' + desc); if (local.length) throw new Error(local[0]);
    await api('POST', '/api/jobs', { title: title, category: $('#pCat').value, skills: P.skills, description: desc, budget: $('#pBudget').value, days: $('#pDays').value });
    toast('Your job is live.'); go('dashboard');
  } else if (kind === 'bid') {
    var note = $('#bNote').value, sc = scan(note); if (sc.length) throw new Error(sc[0]);
    var id = form.dataset.id;
    await api('POST', '/api/jobs/' + id + '/bids', { amount: $('#bAmt').value, days: $('#bDays').value, note: note });
    await refreshMe(); toast('Bid placed.'); openJob(id);
  } else if (kind === 'msg') {
    var inp = $('#msgIn'), body = inp.value.trim(); if (!body) return;
    await api('POST', '/api/bids/' + thr.id + '/messages', { body: body }); inp.value = ''; await pullThread(false);
  } else if (kind === 'pan') {
    var r = await api('POST', '/api/kyc/pan', { name: $('#panName').value, pan: $('#panNo').value }); S.user = r.user; toast(r.user.panStatus === 'approved' ? 'PAN verified.' : 'PAN submitted for review.'); R.account(); paintBanner();
  } else if (kind === 'profile') {
    var p = await api('PUT', '/api/me/profile', { mainCategory: $('#prCat').value, skills: S.prof.skills, bio: $('#prBio').value, upi: $('#prUpi').value }); S.user = p.user; toast('Profile saved.'); paintHeader();
  } else if (kind === 'pw') {
    await api('POST', '/api/me/password', { current: $('#pwC').value, next: $('#pwN').value }); $('#pwC').value = ''; $('#pwN').value = ''; toast('Password updated.');
  } else if (kind === 'deliver') {
    await api('POST', '/api/contracts/' + form.dataset.id + '/deliver', { note: $('#dNote').value }); toast('Delivered. The client has been asked to review.'); openContract(form.dataset.id);
  } else if (kind === 'revision') {
    await api('POST', '/api/contracts/' + form.dataset.id + '/revision', { note: $('#rvNote').value }); toast('Change request sent.'); openContract(form.dataset.id);
  } else if (kind === 'dispute') {
    await api('POST', '/api/contracts/' + form.dataset.id + '/dispute', { reason: $('#dsNote').value }); toast('Dispute raised. Support will review it.'); openContract(form.dataset.id);
  }
}

/* ======================= events ======================= */
var actions = {
  'close-panel': closePanel, 'close-auth': closeAuth, theme: toggleTheme,
  auth: function (a) { openAuth(a.dataset.mode, a.dataset.role || (A.role && a.dataset.mode === 'register' ? A.role : '')); },
  'auth-job': function (a) { var id = a.dataset.id; S.afterAuth = function () { openJob(id); }; closePanel(); openAuth(a.dataset.mode, a.dataset.role); },
  role: function (a) { var keep = { n: $('#rgN') && $('#rgN').value, e: $('#rgE') && $('#rgE').value, m: $('#rgM') && $('#rgM').value }; A.role = a.dataset.role; drawAuth(); if (keep.n) $('#rgN').value = keep.n; if (keep.e) $('#rgE').value = keep.e; if (keep.m) $('#rgM').value = keep.m; },
  logout: async function () { try { await api('POST', '/api/auth/logout'); } catch (e) { /* ignore */ } S.user = null; S.exam = null; go('home'); route(); toast('Logged out.'); },
  job: function (a) { openJob(a.dataset.id); },
  more: function () { S.F.page++; loadJobs(true); },
  thread: function (a) { openThread(a.dataset.id, a.dataset.title); },
  contract: function (a) { openContract(a.dataset.id); },
  accept: async function (a) {
    if (!arm(a, 'Click again to hire ' + a.dataset.name.split(' ')[0])) return;
    try { var d = await api('POST', '/api/bids/' + a.dataset.id + '/accept'); toast('Freelancer selected. Fund escrow to start the work.'); renderContract(d.contract); } catch (e) { toast(e.message, true); }
  },
  'close-job': async function (a) { if (!arm(a, 'Click again to close')) return; try { await api('POST', '/api/jobs/' + a.dataset.id + '/close'); toast('Job closed.'); closePanel(); route(); } catch (e) { toast(e.message, true); } },
  'pay-contract': async function (a) {
    busy(a, true, 'Preparing…');
    try { var o = await api('POST', '/api/contracts/' + a.dataset.id + '/pay'); var res = await payFlow(o, 'Escrow for contract #' + a.dataset.id); if (res) { toast('Escrow funded. The freelancer can start now.'); openContract(a.dataset.id); } else openContract(a.dataset.id); }
    catch (e) { toast(e.message, true); busy(a, false); }
  },
  'cancel-contract': async function (a) { if (!arm(a, 'Click again to cancel')) return; try { await api('POST', '/api/contracts/' + a.dataset.id + '/cancel'); toast('Hire cancelled. Your job is open again.'); closePanel(); route(); } catch (e) { toast(e.message, true); } },
  approve: async function (a) { if (!arm(a, 'Click again to release payment')) return; try { await api('POST', '/api/contracts/' + a.dataset.id + '/approve'); toast('Payment released to the freelancer.'); openContract(a.dataset.id); } catch (e) { toast(e.message, true); } },
  'rev-open': function (a) { $('#subForm').innerHTML = '<form class="stack" data-form="revision" data-id="' + a.dataset.id + '"><div class="field"><label class="lb" for="rvNote">What should be changed?</label><textarea class="inp" id="rvNote"></textarea></div><div class="ferr" hidden></div><div><button class="btn" type="submit">Send change request</button></div></form>'; },
  'dispute-open': function (a) { var box = $('#subForm') || a.parentNode; var f = document.createElement('div'); f.innerHTML = '<form class="stack" data-form="dispute" data-id="' + a.dataset.id + '" style="margin-top:12px"><div class="field"><label class="lb" for="dsNote">Describe the problem (at least 20 characters)</label><textarea class="inp" id="dsNote"></textarea></div><div class="ferr" hidden></div><div><button class="btn" type="submit">Submit dispute</button></div><p class="fine">Payment is frozen until JobLancer support decides.</p></form>'; a.parentNode.parentNode.appendChild(f); a.disabled = true; },
  'otp-send': async function (a) {
    var row = a.closest('[data-otp]'), hint = $('[data-f="hint"]', row); busy(a, true);
    try { var d = await api('POST', '/api/auth/otp/send', { kind: a.dataset.kind }); $('[data-stage="code"]', row).hidden = false; hint.textContent = 'Code sent to ' + d.sentTo + '.' + (d.devCode ? ' Test mode code: ' + d.devCode : ''); }
    catch (e) { hint.textContent = e.message; } busy(a, false);
  },
  'otp-verify': async function (a) {
    var row = a.closest('[data-otp]'), hint = $('[data-f="hint"]', row);
    try { var d = await api('POST', '/api/auth/otp/verify', { kind: a.dataset.kind, code: $('[data-f="code"]', row).value }); S.user = d.user; toast('Verified.'); R.account(); paintHeader(); paintBanner(); }
    catch (e) { hint.textContent = e.message; }
  },
  'exam-start': async function (a) {
    busy(a, true);
    try { startExam(await api('POST', '/api/exam/start', { category: a.dataset.cat })); window.scrollTo(0, 0); }
    catch (e) { busy(a, false); var eb = $('#examCard .ferr'); if (eb) errBox(eb, e); else toast(e.message, true); }
  },
  'exam-for': function (a) { S.examCat = a.dataset.cat; closePanel(); go('account'); },
  'exam-next': function () { var ex = S.exam; if (ex.i === ex.att.total - 1) submitExam(); else { ex.i++; renderExam(); } },
  plan: async function (a) {
    var u = S.user; if (!u) return openAuth('register', 'freelancer');
    busy(a, true);
    try {
      var o = await api('POST', '/api/plans/buy', { plan: a.dataset.plan });
      if (o.done) { S.user = o.user; toast('Switched to Starter.'); paintHeader(); paintPlans(); }
      else { var r = await payFlow(o, S.meta.plans.filter(function (p) { return p.key === a.dataset.plan; })[0].name + ' plan, 30 days'); closePanel(); if (r) { S.user = r.user; toast('Plan activated. ' + r.user.bidsLeft + ' bids available.'); paintHeader(); } paintPlans(); }
    } catch (e) { toast(e.message, true); paintPlans(); }
  },
  atab: function (a) { S.atab = a.dataset.t; $$('#atabs button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.t === S.atab)); }); $('#abody').innerHTML = '<div class="skeleton">Loading…</div>'; loadAdmin(); },
  'pan-ok': async function (a) { try { await api('POST', '/api/admin/pan/' + a.dataset.id, { approve: true }); toast('Approved.'); loadAdmin(); } catch (e) { toast(e.message, true); } },
  'pan-no': async function (a) { try { await api('POST', '/api/admin/pan/' + a.dataset.id, { approve: false, note: $('#pn' + a.dataset.id).value || 'PAN details did not match.' }); toast('Rejected.'); loadAdmin(); } catch (e) { toast(e.message, true); } },
  paid: async function (a) { try { await api('POST', '/api/admin/contracts/' + a.dataset.id + '/payout', { ref: $('#ut' + a.dataset.id).value }); toast('Marked as paid.'); loadAdmin(); } catch (e) { toast(e.message, true); } },
  resolve: async function (a) { if (!arm(a, 'Click again to confirm')) return; try { await api('POST', '/api/admin/disputes/' + a.dataset.id + '/resolve', { action: a.dataset.a, note: $('#dn' + a.dataset.id).value }); toast('Dispute resolved.'); loadAdmin(); } catch (e) { toast(e.message, true); } },
  refunded: async function (a) { try { await api('POST', '/api/admin/payments/' + a.dataset.id + '/refunded', { ref: $('#rf' + a.dataset.id).value }); toast('Marked as refunded.'); loadAdmin(); } catch (e) { toast(e.message, true); } },
  ban: async function (a) { if (!arm(a, 'Click again to confirm')) return; try { await api('POST', '/api/admin/users/' + a.dataset.id + '/status', { status: a.dataset.s }); toast('Updated.'); loadUsers(); } catch (e) { toast(e.message, true); } },
};
document.addEventListener('click', function (e) {
  var g = e.target.closest('[data-go]'); if (g) { e.preventDefault(); closeAuth(); if (g.dataset.go === 'jobs') { if (S.route === 'home') { closePanel(); $('#jobs').scrollIntoView(); } else go('jobs'); } else go(g.dataset.go); return; }
  var a = e.target.closest('[data-act]'); if (a && actions[a.dataset.act]) { if (a.tagName === 'ARTICLE' && e.target.closest('button') && e.target.closest('button') !== a) { /* button inside card handles itself */ } actions[a.dataset.act](a, e); return; }
  var c = e.target.closest('[data-c]'); if (c && $('#catRow') && $('#catRow').contains(c)) { S.F.cat = c.dataset.c; S.F.skill = ''; paintCats(); loadJobs(false); return; }
  var s = e.target.closest('[data-s]'); if (s && $('#skillRow') && $('#skillRow').contains(s)) { S.F.skill = S.F.skill === s.dataset.s ? '' : s.dataset.s; paintCats(); loadJobs(false); return; }
  if (e.target.id === 'ov') closePanel();
  if (e.target.id === 'authOv') closeAuth();
});
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') { if (!$('#authOv').hidden) closeAuth(); else if (!$('#ov').hidden) closePanel(); }
  if (e.key === 'Enter' && e.target.matches && e.target.matches('article[data-act="job"]')) openJob(e.target.dataset.id);
});
document.addEventListener('submit', function (e) {
  var f = e.target.closest('form'); if (!f) return;
  e.preventDefault();
  if (f.id === 'heroSearch') { S.F.q = $('#heroQ').value.trim(); S.F.cat = 'All'; S.F.skill = ''; $('#q').value = S.F.q; paintCats(); loadJobs(false); $('#jobs').scrollIntoView(); return; }
  if (f.dataset.form) submitForm(f, e);
});
var qT;
document.addEventListener('input', function (e) {
  var t = e.target;
  if (t.id === 'q') { clearTimeout(qT); qT = setTimeout(function () { S.F.q = t.value.trim(); loadJobs(false); }, 300); }
  else if (t.id === 'bAmt') calcBid();
  else if (t.id === 'pDesc' || t.id === 'pTitle') { var d = $('#pDesc'); if (!d) return; $('#descCount').textContent = d.value.length; var r = scan($('#pTitle').value + '\n' + d.value); $('#scanHint').textContent = r.length ? r[0] : ''; }
  else if (t.id === 'uq') { clearTimeout(qT); qT = setTimeout(loadUsers, 300); }
});
document.addEventListener('change', function (e) {
  var t = e.target;
  if (t.id === 'sort') { S.F.sort = t.value; loadJobs(false); }
  else if (t.id === 'calc') paintPlans();
  else if (t.id === 'ur') loadUsers();
  else if (t.id === 'pCat') { S.post.skills = []; var c = catByName(t.value); bindChips($('#pSkills'), c ? c.s : [], S.post.skills, 5); }
  else if (t.name === 'opt' && S.exam) { S.exam.answers[S.exam.i] = parseInt(t.value, 10); var nb = $('[data-act="exam-next"]'); if (nb) nb.disabled = false; }
});
document.addEventListener('input', function (e) { if (e.target.id === 'calc') paintPlans(); });

/* ---------- boot ---------- */
(async function () {
  try {
    var m = await api('GET', '/api/meta'); S.meta = m;
    $('#modeNote').textContent = m.paymentsMode === 'mock' ? 'Test mode: payments are simulated' : '';
    var me = await api('GET', '/api/me'); S.user = me.user;
  } catch (e) { $('#app').innerHTML = '<div class="wrap sec"><div class="alert">Could not reach the server. Please refresh the page.</div></div>'; return; }
  route();
})();
})();
