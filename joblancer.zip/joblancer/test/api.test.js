'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startServer, newUser, verifyContacts, passExam } = require('./helpers');

let srv;
test.before(async () => { srv = await startServer(); });
test.after(() => srv.stop());

const goodJob = (over) => Object.assign({ title: 'Build a landing page for my bakery', category: 'Development', skills: ['Web Development'],
  description: 'I need a simple one page website for my bakery with menu, photos and a contact form. Mobile friendly and fast.', budget: 12000, days: 10 }, over || {});

test('security headers and health', async () => {
  const c = srv.client();
  const r = await c.get('/healthz');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
});

test('register validation and duplicates', async () => {
  const c = srv.client();
  assert.equal((await c.post('/api/auth/register', { role: 'admin', name: 'X Y', email: 'a@b.co', phone: '9876543210', password: 'Passw0rd!x' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { role: 'client', name: 'Ok Name', email: 'bad', phone: '9876543210', password: 'Passw0rd!x' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { role: 'client', name: 'Ok Name', email: 'x@mailinator.com', phone: '9876543210', password: 'Passw0rd!x' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { role: 'client', name: 'Ok Name', email: 'ok@mail.test', phone: '1234567890', password: 'Passw0rd!x' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { role: 'client', name: 'Ok Name', email: 'ok@mail.test', phone: '9876543210', password: 'short' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { role: 'freelancer', name: 'Ok Name', email: 'ok@mail.test', phone: '9876543210', password: 'Passw0rd!x' })).status, 400, 'freelancer needs a category');
  const { r, body } = await newUser(srv, 'client');
  assert.equal(r.status, 200);
  assert.equal(r.data.user.role, 'client');
  assert.equal(r.data.user.canPost, false);
  const dup = await srv.client().post('/api/auth/register', Object.assign({}, body, { phone: '9000011122' }));
  assert.equal(dup.status, 409);
});

test('login, session, logout, lockout', async () => {
  const { c, body } = await newUser(srv, 'client');
  assert.equal((await c.get('/api/me')).data.user.email, body.email.toLowerCase());
  await c.post('/api/auth/logout');
  assert.equal((await c.get('/api/me')).data.user, null);
  const c2 = srv.client();
  assert.equal((await c2.post('/api/auth/login', { email: body.email, password: 'Passw0rd!x' })).status, 200);
  const c3 = srv.client();
  for (let i = 0; i < 8; i++) assert.equal((await c3.post('/api/auth/login', { email: body.email, password: 'wrong-pass1' })).status, 401);
  const locked = await c3.post('/api/auth/login', { email: body.email, password: 'Passw0rd!x' });
  assert.equal(locked.status, 429, 'account locks after 8 failures even with the right password');
});

test('otp verification, wrong code, forgot and reset password', async () => {
  const { c, body } = await newUser(srv, 'freelancer');
  const s = await c.post('/api/auth/otp/send', { kind: 'phone' });
  assert.equal(s.status, 200);
  assert.equal((await c.post('/api/auth/otp/send', { kind: 'phone' })).status, 429, 'resend cooldown');
  const wrong = await c.post('/api/auth/otp/verify', { kind: 'phone', code: s.data.devCode === '000000' ? '111111' : '000000' });
  assert.equal(wrong.status, 400);
  const ok = await c.post('/api/auth/otp/verify', { kind: 'phone', code: s.data.devCode });
  assert.equal(ok.data.user.phoneVerified, true);
  const f = await srv.client().post('/api/auth/forgot', { email: body.email });
  assert.equal(f.status, 200);
  const rc = srv.client();
  assert.equal((await rc.post('/api/auth/reset', { email: body.email, code: '123456', password: 'NewPassw0rd' })).status, 400);
  assert.equal((await rc.post('/api/auth/reset', { email: body.email, code: f.data.devCode, password: 'NewPassw0rd' })).status, 200);
  assert.equal((await rc.post('/api/auth/login', { email: body.email, password: 'NewPassw0rd' })).status, 200);
  assert.equal((await c.get('/api/me')).data.user, null, 'old sessions are signed out after reset');
  assert.equal((await srv.client().post('/api/auth/forgot', { email: 'nobody@mail.test' })).status, 200, 'no account enumeration');
});

test('cross-site requests and bad bodies are blocked', async () => {
  const c = srv.client();
  const r = await c.call('POST', '/api/auth/login', { email: 'a@b.co', password: 'x' }, { origin: 'https://evil.example' });
  assert.equal(r.status, 403);
  const res = await fetch(srv.base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'text/plain', 'x-forwarded-for': '10.9.9.9' }, body: 'hello' });
  assert.equal(res.status, 415);
});

test('client must verify before posting; fraud scan; caps', async () => {
  const { c } = await newUser(srv, 'client');
  assert.equal((await c.post('/api/jobs', goodJob())).status, 403);
  await verifyContacts(c);
  assert.equal((await c.post('/api/jobs', goodJob())).status, 403, 'needs PAN');
  assert.equal((await c.post('/api/kyc/pan', { name: 'Test Client', pan: 'BAD123' })).status, 400);
  const pan = 'ABCPE' + String(1000 + Math.floor(Math.random() * 8999)) + 'F';
  const p = await c.post('/api/kyc/pan', { name: 'Test Client', pan });
  assert.equal(p.status, 200);
  assert.equal(p.data.user.panStatus, 'approved');
  assert.equal(p.data.user.canPost, true);
  const other = (await newUser(srv, 'client')).c; await verifyContacts(other);
  assert.equal((await other.post('/api/kyc/pan', { name: 'Someone Else', pan })).status, 409, 'one PAN, one account');

  for (const [desc, field] of [['Call me on 9876543210 for details about this project and the budget please', 'phone'], ['Mail the details to someone@gmail.com and we can start the project right away today', 'email'],
    ['Pay a registration fee of 500 first and then we begin the work on the project for you', 'fee'], ['Contact me on WhatsApp for the full brief and payment outside the platform quickly', 'chat']]) {
    const r = await c.post('/api/jobs', goodJob({ description: desc }));
    assert.equal(r.status, 400, field + ' must be blocked');
  }
  assert.equal((await c.post('/api/jobs', goodJob({ budget: 30000 }))).status, 400, 'new client cap');
  assert.equal((await c.post('/api/jobs', goodJob({ skills: ['Voice Over'] }))).status, 400, 'skill must belong to category');
  const ok = await c.post('/api/jobs', goodJob());
  assert.equal(ok.status, 200);
  assert.equal((await c.post('/api/jobs', goodJob())).status, 409, 'duplicate title');
  const list = await srv.client().get('/api/jobs?q=bakery');
  assert.ok(list.data.jobs.some((j) => j.id === ok.data.job.id));
  assert.equal(list.data.jobs[0].client.name, 'Client T.');
  assert.equal(list.data.jobs[0].client.email, undefined);
});

test('exam: no answers leaked, fail then cooldown, pass gives badge', async () => {
  const { c } = await newUser(srv, 'freelancer');
  assert.equal((await c.post('/api/exam/start', { category: 'Development' })).status, 403, 'verify first');
  await verifyContacts(c);
  const st = await c.post('/api/exam/start', { category: 'Development' });
  assert.equal(st.status, 200);
  assert.equal(st.data.questions.length, 8);
  assert.ok(!JSON.stringify(st.data).includes('"c"'), 'no answer key in response');
  const again = await c.post('/api/exam/start', { category: 'Development' });
  assert.equal(again.data.attemptId, st.data.attemptId, 'resumes the same attempt');
  const bad = await c.post('/api/exam/' + st.data.attemptId + '/submit', { answers: [9, 9, 9, 9, 9, 9, 9, 9] });
  assert.equal(bad.data.passed, false);
  assert.equal((await c.post('/api/exam/start', { category: 'Development' })).status, 429, '24h cooldown');
  const d = srv.db(); d.prepare('UPDATE users SET exam_next_at=0 WHERE email=?').run((await c.get('/api/me')).data.user.email); d.close();
  const pass = await passExam(srv, c, 'Development');
  assert.equal(pass.data.passed, true);
  const me = (await c.get('/api/me')).data.user;
  assert.equal(me.canBid, true);
  assert.equal(me.badges[0].category, 'Development');
});

test('exam: leaving the tab twice ends the attempt; late submit fails', async () => {
  const { c } = await newUser(srv, 'freelancer', { category: 'Design' });
  await verifyContacts(c);
  const st = await c.post('/api/exam/start', { category: 'Design' });
  assert.equal((await c.post('/api/exam/' + st.data.attemptId + '/switch')).data.ended, false);
  assert.equal((await c.post('/api/exam/' + st.data.attemptId + '/switch')).data.ended, true);
  assert.equal((await c.post('/api/exam/' + st.data.attemptId + '/submit', { answers: [] })).status, 400);
  const { c: c2 } = await newUser(srv, 'freelancer', { category: 'Marketing' });
  await verifyContacts(c2);
  const s2 = await c2.post('/api/exam/start', { category: 'Marketing' });
  const d = srv.db(); d.prepare('UPDATE exam_attempts SET ends_at=? WHERE id=?').run(Date.now() - 60000, s2.data.attemptId); d.close();
  const late = await c2.post('/api/exam/' + s2.data.attemptId + '/submit', { answers: [0, 0, 0, 0, 0, 0, 0, 0] });
  assert.equal(late.data.expired, true);
});

async function setupDeal(opts) {
  opts = opts || {};
  const client = (await newUser(srv, 'client')).c; await verifyContacts(client);
  await client.post('/api/kyc/pan', { name: 'Deal Client', pan: 'ABCPE' + String(1000 + Math.floor(Math.random() * 8999)) + 'F' });
  const fl = (await newUser(srv, 'freelancer')).c; await verifyContacts(fl);
  assert.equal((await passExam(srv, fl, 'Development')).data.passed, true);
  if (opts.plan) { const o = await fl.post('/api/plans/buy', { plan: opts.plan }); await fl.post('/api/payments/verify', { paymentId: o.data.paymentId, razorpay_signature: 'mock-ok' }); }
  const job = (await client.post('/api/jobs', goodJob({ title: 'Deal job ' + Math.random().toString(36).slice(2, 8) + ' for tests', budget: 10000 }))).data.job;
  const bid = await fl.post('/api/jobs/' + job.id + '/bids', { amount: 10000, days: 7, note: 'I have built many similar sites and can deliver this in a week with two rounds of changes included.' });
  assert.equal(bid.status, 200);
  return { client, fl, job, bidId: bid.data.bidId };
}

test('bidding rules', async () => {
  const { client, fl, job, bidId } = await setupDeal();
  assert.equal((await fl.post('/api/jobs/' + job.id + '/bids', { amount: 9000, days: 5, note: 'Another proposal that is long enough to pass the length check okay.' })).status, 409, 'one bid per job');
  const me = (await fl.get('/api/me')).data.user; assert.equal(me.bidsLeft, 9);
  const designer = (await newUser(srv, 'freelancer', { category: 'Design' })).c; await verifyContacts(designer);
  assert.equal((await passExam(srv, designer, 'Design')).data.passed, true);
  assert.equal((await designer.post('/api/jobs/' + job.id + '/bids', { amount: 9000, days: 5, note: 'I am a designer and can do this well, here is my long enough proposal text.' })).status, 403, 'needs a badge for the job category');
  assert.equal((await client.post('/api/jobs/' + job.id + '/bids', { amount: 9000, days: 5, note: 'x'.repeat(60) })).status, 403, 'clients cannot bid');
  const leak = await fl.post('/api/jobs/' + job.id + '/close');
  assert.equal(leak.status, 403);
  assert.equal((await fl.get('/api/jobs/' + job.id + '/bids')).status, 403);
  const other = (await newUser(srv, 'client')).c;
  assert.equal((await other.get('/api/jobs/' + job.id + '/bids')).status, 404, "another client cannot see a job's bids");
  const list = await client.get('/api/jobs/' + job.id + '/bids');
  assert.equal(list.data.bids.length, 1);
  assert.equal(list.data.bids[0].freelancer.name, 'Freelancer T.');
  assert.equal((await fl.post('/api/bids/' + bidId + '/messages', { body: 'Call me on 9876543210' })).status, 400);
  assert.equal((await fl.post('/api/bids/' + bidId + '/messages', { body: 'See https://example.com/work' })).status, 400, 'no links before escrow');
  assert.equal((await fl.post('/api/bids/' + bidId + '/messages', { body: 'Happy to start. Any reference sites?' })).status, 200);
  assert.equal((await other.get('/api/bids/' + bidId + '/messages')).status, 403);
  assert.equal((await client.get('/api/bids/' + bidId + '/messages')).data.messages.length, 1);
});

test('full escrow lifecycle with commission and payout', async () => {
  const { client, fl, job, bidId } = await setupDeal({ plan: 'pro' });
  const acc = await client.post('/api/bids/' + bidId + '/accept');
  assert.equal(acc.status, 200);
  const k = acc.data.contract;
  assert.equal(k.status, 'awaiting_payment');
  assert.equal(k.amountPaise, 1000000);
  assert.equal(k.clientFeePaise, 20000, '2% protection fee');
  assert.equal(k.totalPaise, 1020000);
  assert.equal((await client.post('/api/bids/' + bidId + '/accept')).status, 400, 'cannot hire twice');
  assert.equal((await fl.post('/api/contracts/' + k.id + '/deliver', { note: 'Done already, look at it please.' })).status, 400, 'cannot deliver before escrow');
  const flView = (await fl.get('/api/my/contracts')).data.contracts[0];
  assert.equal(flView.commissionPct, 10, 'pro plan commission');
  assert.equal(flView.receivePaise, 900000);

  const order = await client.post('/api/contracts/' + k.id + '/pay');
  assert.equal(order.data.amountPaise, 1020000);
  assert.equal((await client.post('/api/payments/verify', { paymentId: order.data.paymentId, razorpay_signature: 'forged' })).status, 400);
  assert.equal((await fl.post('/api/payments/verify', { paymentId: order.data.paymentId, razorpay_signature: 'mock-ok' })).status, 404, "someone else's payment");
  assert.equal((await client.post('/api/payments/verify', { paymentId: order.data.paymentId, razorpay_signature: 'mock-ok' })).status, 200);
  assert.equal((await client.post('/api/payments/verify', { paymentId: order.data.paymentId, razorpay_signature: 'mock-ok' })).data.already, true, 'idempotent');
  assert.equal((await client.get('/api/contracts/' + k.id)).data.contract.status, 'funded');
  assert.equal((await fl.post('/api/bids/' + bidId + '/messages', { body: 'Files here: https://drive.example.com/abc' })).status, 200, 'links allowed after escrow');

  assert.equal((await client.post('/api/contracts/' + k.id + '/approve')).status, 400, 'nothing delivered yet');
  assert.equal((await fl.post('/api/contracts/' + k.id + '/deliver', { note: 'Delivered. Files at https://drive.example.com/final' })).status, 200);
  assert.equal((await fl.post('/api/contracts/' + k.id + '/approve')).status, 403, 'freelancer cannot approve');
  const rev = await client.post('/api/contracts/' + k.id + '/revision', { note: 'Please change the header colour to green.' });
  assert.equal(rev.data.contract.status, 'funded');
  await fl.post('/api/contracts/' + k.id + '/deliver', { note: 'Updated with the green header as requested.' });
  const ap = await client.post('/api/contracts/' + k.id + '/approve');
  assert.equal(ap.data.contract.status, 'released');

  const admin = srv.client(); assert.equal((await admin.post('/api/auth/login', { email: 'admin@jl.test', password: 'Admin@12345' })).status, 200);
  assert.equal((await client.get('/api/admin/summary')).status, 403);
  const sum = (await admin.get('/api/admin/summary')).data;
  assert.ok(sum.commissionPaise >= 100000);
  const pend = (await admin.get('/api/admin/contracts?payout=pending')).data.contracts.find((c) => c.id === k.id);
  assert.equal(pend.payoutPaise, 900000);
  assert.equal(pend.payoutTo, 'freelancer');
  assert.equal((await admin.post('/api/admin/contracts/' + k.id + '/payout', { ref: 'UTR123456789' })).status, 200);
  assert.equal((await fl.get('/api/my/contracts')).data.contracts[0].payoutStatus, 'paid');
  assert.equal((await client.get('/api/jobs/' + job.id)).data.job.status, 'completed');
});

test('dispute resolved by admin with refund', async () => {
  const { client, fl, bidId } = await setupDeal();
  const k = (await client.post('/api/bids/' + bidId + '/accept')).data.contract;
  const o = await client.post('/api/contracts/' + k.id + '/pay');
  await client.post('/api/payments/verify', { paymentId: o.data.paymentId, razorpay_signature: 'mock-ok' });
  await fl.post('/api/contracts/' + k.id + '/deliver', { note: 'Here is the finished work as agreed.' });
  const d = await client.post('/api/contracts/' + k.id + '/dispute', { reason: 'The delivered work does not match the brief at all.' });
  assert.equal(d.data.contract.status, 'disputed');
  assert.equal((await client.post('/api/contracts/' + k.id + '/approve')).status, 400);
  const admin = srv.client(); await admin.post('/api/auth/login', { email: 'admin@jl.test', password: 'Admin@12345' });
  const disputes = (await admin.get('/api/admin/disputes')).data.disputes;
  const mine = disputes.find((x) => x.contractId === k.id); assert.ok(mine);
  assert.equal((await admin.post('/api/admin/disputes/' + mine.id + '/resolve', { action: 'refund', note: 'Work did not match the brief.' })).status, 200);
  const cv = (await admin.get('/api/admin/contracts?status=refunded')).data.contracts.find((x) => x.id === k.id);
  assert.equal(cv.payoutTo, 'client');
  assert.equal(cv.payoutPaise, 1020000);
});

test('cancel an unpaid hire reopens the job; unpaid hire does not reject other bids', async () => {
  const { client, bidId, job } = await setupDeal();
  const k = (await client.post('/api/bids/' + bidId + '/accept')).data.contract;
  assert.equal((await client.get('/api/jobs/' + job.id)).data.job.status, 'in_progress');
  assert.equal((await client.post('/api/contracts/' + k.id + '/cancel')).status, 200);
  assert.equal((await client.get('/api/jobs/' + job.id)).data.job.status, 'open');
  assert.equal((await client.get('/api/jobs/' + job.id + '/bids')).data.bids[0].status, 'pending');
});

test('plans: purchase needs a valid payment signature; commission follows plan', async () => {
  const fl = (await newUser(srv, 'freelancer')).c;
  const o = await fl.post('/api/plans/buy', { plan: 'elite' });
  assert.equal(o.data.amountPaise, 149900);
  assert.equal((await fl.get('/api/me')).data.user.plan, 'free');
  assert.equal((await fl.post('/api/payments/verify', { paymentId: o.data.paymentId, razorpay_signature: 'nope' })).status, 400);
  assert.equal((await fl.get('/api/me')).data.user.plan, 'free');
  const v = await fl.post('/api/payments/verify', { paymentId: o.data.paymentId, razorpay_signature: 'mock-ok' });
  assert.equal(v.data.user.plan, 'elite'); assert.equal(v.data.user.bidsLeft, 120);
  assert.equal((await fl.post('/api/plans/buy', { plan: 'gold' })).status, 400);
});

test('admin: PAN review queue and suspension', async () => {
  const s2 = await startServer({ PAN_AUTO_APPROVE: '0' });
  try {
    const c = (await newUser(s2, 'client')).c; await verifyContacts(c);
    const p = await c.post('/api/kyc/pan', { name: 'Review Me', pan: 'ABCPE1234F' });
    assert.equal(p.data.user.panStatus, 'pending');
    assert.equal((await c.post('/api/jobs', goodJob())).status, 403);
    const admin = s2.client(); await admin.post('/api/auth/login', { email: 'admin@jl.test', password: 'Admin@12345' });
    const q = (await admin.get('/api/admin/pan')).data.items;
    assert.equal(q.length, 1); assert.equal(q[0].pan, 'ABCPE1234F');
    assert.equal((await admin.post('/api/admin/pan/' + q[0].id, { approve: true })).status, 200);
    assert.equal((await c.post('/api/jobs', goodJob())).status, 200);
    const me = (await c.get('/api/me')).data.user;
    assert.equal((await admin.post('/api/admin/users/' + me.id + '/status', { status: 'banned', reason: 'test' })).status, 200);
    assert.equal((await c.get('/api/me')).data.user, null, 'banned user is signed out immediately');
    assert.equal((await srv.client().post('/api/auth/login', { email: me.email, password: 'Passw0rd!x' })).status, 401);
  } finally { s2.stop(); }
});
