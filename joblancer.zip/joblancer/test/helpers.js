'use strict';
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

let ipCounter = 10;
class Client {
  constructor(base) { this.base = base; this.cookie = ''; this.ip = '10.0.0.' + (++ipCounter); }
  async call(method, url, body, headers) {
    const res = await fetch(this.base + url, {
      method, redirect: 'manual',
      headers: Object.assign({ 'content-type': 'application/json', cookie: this.cookie, 'x-forwarded-for': this.ip }, headers || {}),
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    sc.forEach((c) => { const kv = c.split(';')[0]; if (kv.endsWith('=')) this.cookie = ''; else this.cookie = kv; });
    let data = null; try { data = await res.json(); } catch {}
    return { status: res.status, data, headers: res.headers };
  }
  get(u) { return this.call('GET', u); }
  post(u, b) { return this.call('POST', u, b || {}); }
  put(u, b) { return this.call('PUT', u, b || {}); }
}

async function startServer(extraEnv) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jl-test-'));
  const dbPath = path.join(dir, 'test.db');
  const port = 20000 + Math.floor(Math.random() * 20000);
  const env = Object.assign({}, process.env, { PORT: String(port), DB_PATH: dbPath, ADMIN_EMAIL: 'admin@jl.test', ADMIN_PASSWORD: 'Admin@12345', NODE_ENV: 'development', NODE_NO_WARNINGS: '1' }, extraEnv || {});
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  await new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('server did not start: ' + out)), 8000);
    const on = (d) => { out += d; if (/running on port/.test(out)) { clearTimeout(t); resolve(); } };
    child.stdout.on('data', on); child.stderr.on('data', (d) => { out += d; });
    child.on('exit', (c) => { clearTimeout(t); reject(new Error('server exited ' + c + ': ' + out)); });
  });
  const base = 'http://127.0.0.1:' + port;
  const db = () => new DatabaseSync(dbPath);
  return { base, dbPath, db, stop: () => child.kill('SIGTERM'), client: () => new Client(base), logs: () => out };
}

let n = 0;
async function newUser(srv, role, over) {
  const c = srv.client(); n++;
  const body = Object.assign({ role, name: (role === 'client' ? 'Client' : 'Freelancer') + ' Tester', email: role + n + '-' + Date.now() + '@mail.test', phone: '9' + String(100000000 + n * 7 + Math.floor(Math.random() * 1000000)).slice(0, 9), password: 'Passw0rd!x', category: role === 'freelancer' ? 'Development' : undefined }, over || {});
  const r = await c.post('/api/auth/register', body);
  return { c, body, r };
}
async function verifyContacts(c) {
  for (const kind of ['email', 'phone']) {
    const s = await c.post('/api/auth/otp/send', { kind });
    if (s.status !== 200 || !s.data.devCode) throw new Error('otp send failed ' + JSON.stringify(s.data));
    const v = await c.post('/api/auth/otp/verify', { kind, code: s.data.devCode });
    if (v.status !== 200) throw new Error('otp verify failed ' + JSON.stringify(v.data));
  }
}
function passExam(srv, c, category) {
  return (async () => {
    const st = await c.post('/api/exam/start', { category });
    if (st.status !== 200) throw new Error('exam start ' + JSON.stringify(st.data));
    const id = st.data.attemptId;
    const d = srv.db();
    const qs = JSON.parse(d.prepare('SELECT questions FROM exam_attempts WHERE id=?').get(id).questions); d.close();
    return c.post('/api/exam/' + id + '/submit', { answers: qs.map((q) => q.c) });
  })();
}
module.exports = { startServer, newUser, verifyContacts, passExam };
